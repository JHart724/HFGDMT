// eslint.config.mjs
import js from "@eslint/js";
import globals from "globals";

export default [
    js.configs.recommended,
    {
        languageOptions: {
            ecmaVersion: 2022,
            sourceType: "module",
            globals: {
                ...globals.node,
                ...globals.express,
                Parse: true, // For Parse Platform global
            },
        },
        rules: {
            // Common preferences
            "semi": ["error", "always"],
            "quotes": ["error", "double"],
            "indent": ["error", 4, {"SwitchCase": 1}],

            // Debugging
            "no-console": "off",
            "no-unused-vars": "warn",

            // Node/Express specific
            "no-process-exit": "error",
            "handle-callback-err": "error",

            // Common preferences for async code (common in Parse/Express)
            "no-return-await": "error",
        },
    },
];
