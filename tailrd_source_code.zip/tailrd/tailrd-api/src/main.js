import express from "express";
import { ParseServer } from "parse-server";
import sendGridAdapter from "parse-server-sendgrid-email-adapter";
import path from "path";
import { fileURLToPath } from "url";
import { readFile } from "fs/promises";
import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager";
import axios from "axios";

// Determine the directory name
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __packageJsonPath = path.join(__dirname, "../package.json");
const { version } = JSON.parse(await readFile(__packageJsonPath, "utf8"));

const main = express();

const {
    PORT,
    BASE_URL, // Either use BASE_URL or use SERVER_URL, PUBLIC_URL, and STATIC_CONTENT_URL.
    DB_SECRET_ID,
    DB_NAME,
    DB_HOST,
    DB_PORT,
    SERVER_URL,
    PUBLIC_URL,
    STATIC_CONTENT_URL,
    MOUNT_POINT,
    APP_ID,
    JAVASCRIPT_KEY,
    MASTER_KEY,
    MASTER_KEY_IPS,
    SG_API_KEY,
    SG_FROM_EMAIL
} = process.env;

const dbSecretId = DB_SECRET_ID ?? null;
const dbHost = DB_HOST ?? "localhost";
const dbPort = DB_PORT ?? "5432";
const dbName = DB_NAME ?? "tailrd-db-dev";
const port = PORT ?? 1337;
const mountPoint = MOUNT_POINT ?? "api";
const baseURL = BASE_URL ?? `http://localhost:${port}`;
const serverURL = SERVER_URL ?? `${baseURL}/${mountPoint}`;
const publicServerURL = PUBLIC_URL ?? serverURL;
const staticContentURL = STATIC_CONTENT_URL ?? baseURL;
const appId = APP_ID ?? "myAppId";
const javascriptKey = JAVASCRIPT_KEY ?? "myJSKey";
const masterKey = MASTER_KEY ?? "myMasterKey";
const masterKeyIps = MASTER_KEY_IPS ?? ["0.0.0.0/0", "::/0"];
const sendGridApiKey = SG_API_KEY ?? "NO_SG_API_KEY";

const webhookWhitelist = ["/sendgrid"];

async function getDatabaseConfig() {
    const dbDefaultCredentials = { username: "app-user-dev", password: "Test123!" };

    if (!dbSecretId) {
        console.warn("[API] No DB credentials provided, falling back to local default.");
        return dbDefaultCredentials;
    }

    try {
        const client = new SecretsManagerClient({ region: "us-east-2" });

        const response = await client.send(
            new GetSecretValueCommand({ SecretId: dbSecretId })
        );

        return {...dbDefaultCredentials, ...JSON.parse(response.SecretString)};
    } catch (error) {
        console.error("[API] Failed to get database config. Falling back to local default settings. Error:", error);
        return dbDefaultCredentials;
    }
}

// Modify your main code to be async and use this:
const { username: dbUsername, password: dbPassword } = await getDatabaseConfig();
const databaseURI = `postgres://${dbUsername}:${dbPassword}@${dbHost}:${dbPort}/${dbName}`;

const server = new ParseServer({
    appName: "TAILRD",
    cloud: new URL("./cloud/main.js", import.meta.url).pathname,
    databaseURI,
    appId,
    javascriptKey,
    masterKey,
    serverURL,
    publicServerURL,
    masterKeyIps,
    liveQuery: {
        classNames: [],
    },
    customPages: {
        invalidLink: `${staticContentURL}/landing/invalid_link.html`,
        verifyEmailSuccess: `${staticContentURL}/landing/verify_email_success.html`,
        choosePassword: `${staticContentURL}/landing/choose_password.html`,
        passwordResetSuccess: `${staticContentURL}/landing/password_reset_success.html`,
        invalidVerificationLink: `${staticContentURL}/landing/invalid_verification_link.html`,
        linkSendFail: `${staticContentURL}/landing/link_send_fail.html`,
        linkSendSuccess: `${staticContentURL}/landing/link_send_success.html`,
    },
    emailAdapter: sendGridAdapter({
        apiKey: sendGridApiKey,
        from: SG_FROM_EMAIL ?? "test@test.com",
        passwordResetEmailTemplate: "d-8eb6edfa3d1f4c04990c88a812ce333b",
        verificationEmailTemplate: "d-cc643e79629c479fa6bd84d47791241f",
    }),
    encodeParseObjectInCloudFunction: true,
});

// Serve the static files from the React app
main.use("/css", express.static(path.join(__dirname, "/public/css")));
main.use("/img", express.static(path.join(__dirname, "/public/img")));
main.use("/fonts", express.static(path.join(__dirname, "/public/fonts")));
main.use("/landing", express.static(path.join(__dirname, "/public/landing")));
main.use("/", express.static(path.join(__dirname, "public")));

main.use("/webhook", express.json({ limit: "50mb" }), async (req, res) => {
    // Check if this is a POST request and if the URL is in the whitelist
    if (req.method === "POST" && webhookWhitelist.includes(req.url)) {
        try {
            // Prepare the forwarded URL
            const forwardUrl = `${staticContentURL}/api/functions${req.url}`;

            // Prepare headers with Parse authentication
            const headers = {
                "Content-Type": "application/json",
                "X-Parse-Application-Id": appId,
                "X-Parse-JavaScript-Key": javascriptKey
            };

            // Forward the request using axios
            const response = await axios.post(forwardUrl, { body: req.body }, { headers });

            // Return the response from the forwarded request
            return res.status(response.status).json(response.data);
        } catch (error) {
            console.error("[API] Webhook proxy error:", error.message);
            return res.status(error.response?.status || 500).json({
                error: "Error forwarding webhook request",
                message: error.message
            });
        }
    } else {
        return res.status(404).send("Not found");
    }
});

// Start Parse Server
await server.start();
main.use(`/${mountPoint}`, server.app);

main.listen(port, () => {
    console.log("[API] API Started: ", {
        version,
        serverURL,
        publicServerURL,
        staticContentURL,
        appId,
        javascriptKey,
        masterKeyIps,
        databaseURI: `postgres://${dbUsername}:***@${dbHost}:${dbPort}/${dbName}`
    });
    console.log(`[API] To check API status: ${publicServerURL}/health`);
});
