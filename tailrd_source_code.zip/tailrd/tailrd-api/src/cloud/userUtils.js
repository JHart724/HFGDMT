import { customAlphabet } from "nanoid";
import mailer from "./mailer.js";
import securityUtils from "./securityUtils.js";

const RegistrationCode = Parse.Object.extend("RegistrationCode");
const Organization = Parse.Object.extend("Organization");

const nanoid = customAlphabet("1234567890ABCDEFGHIJKLMNOPQRSTUVXYZabcdeffghijklmnopqrstuvxyz", 32);

const send = async ({ user, params: { id, email } }) => {
    await securityUtils.requireAdmin(user);

    const organization = new Organization({ id });

    if (!organization) {
        throw new Parse.Error(Parse.Error.OBJECT_NOT_FOUND, "Organization not found.");
    }

    try {
        const code = nanoid();
        const expires = new Date();
        expires.setHours(expires.getHours() + 12);

        const messageId = await mailer.sendInvite(email, code);

        const regCode =await new RegistrationCode({
            code,
            expires,
            organization,
            email,
            messageId,
            sent: new Date(),
            status: "PENDING"
        }).save(null, { useMasterKey: true });


        return regCode;
    } catch (error) {
        console.error("Failed to send invite.", error);
        throw new Parse.Error(Parse.Error.INTERNAL_SERVER_ERROR, "Failed to send invite.");
    }
};

const register = async ({ params: { username, registrationCode, password } }) => {
    const regCodeObj = await new Parse.Query(RegistrationCode)
        .equalTo("status", "PENDING")
        .equalTo("code", registrationCode)
        .select(["expires", "email", "organization"])
        .first({ useMasterKey: true });

    if (!regCodeObj) {
        throw new Parse.Error(Parse.Error.OBJECT_NOT_FOUND, "Registration code not found.");
    }

    const now = new Date();
    if (regCodeObj.get("expires") < now) {
        throw new Parse.Error(Parse.Error.VALIDATION_ERROR, "Registration code has expired.");
    }

    try {
        const email = regCodeObj.get("email");
        const organization = await regCodeObj.get("organization").fetch({ useMasterKey: true });
        const userRole = await organization.get("userRole").fetch({ useMasterKey: true });

        if (!userRole) {
            throw new Parse.Error(Parse.Error.OBJECT_NOT_FOUND, "User role not found for this organization.");
        }

        const user = await new Parse.User()
            .set("username", username)
            .set("password", password)
            .set("email", email)
            .set("organization", organization)
            .signUp();

        await securityUtils.grant(user, userRole);

        await regCodeObj.save({ status: "USED" }, { useMasterKey: true });

        return user;
    } catch (error) {
        console.error("Failed to register user.", error);
        throw error;
    }
};

const authorize = async ({ user }) => {
    const auths = [];
    const sessionToken = user?.getSessionToken();
    const active = user?.get("active") ?? false;
    const organization = await user?.get("organization")?.fetch({ sessionToken });

    if (!sessionToken || !active || !organization) {
        return [];
    }

    const [isOrgUser, isOrgAdmin, isSystemAdmin] = await Promise.all([
        securityUtils.isUserInRole({ user, role: organization.get("userRole") }),
        securityUtils.isUserInRole({ user, role: organization.get("adminRole") }),
        securityUtils.isUserInRole({ user, role: "ADMIN" })
    ]);

    if (isOrgUser || isOrgAdmin) {
        auths.push("USER");
    }

    if (isOrgAdmin) {
        auths.push("ADMIN");
    }

    if (isSystemAdmin) {
        auths.push("SYS_ADMIN");
    }

    return auths;
};

const list = async ({ user, params: { id, isActive } }) => {
    await securityUtils.requireAdmin(user);

    // Get the organization's users
    const users = await new Parse.Query(Parse.User)
        .equalTo("organization", new Organization({id}))
        .equalTo("active", isActive)
        .select("email", "active", "createdAt", "updatedAt")
        .findAll({useMasterKey: true});

    // Format the results
    return users.map(user => ({
        id: user.id,
        email: user.get("email"),
        active: user.get("active"),
        createdAt: user.get("createdAt"),
        updatedAt: user.get("updatedAt")
    }));
};

const changeUserStatus = async ({ user, params: { id, isActive } }) => {
    await securityUtils.requireAdmin(user);

    try {
        const targetUser = await new Parse.Query(Parse.User).get(id, { useMasterKey: true });
        await targetUser.save({ active: isActive }, { useMasterKey: true });

        return {
            id: targetUser.id,
            email: targetUser.get("email"),
            active: targetUser.get("active"),
            createdAt: targetUser.get("createdAt"),
            updatedAt: targetUser.get("updatedAt")
        };
    } catch {
        throw new Parse.Error(Parse.Error.OBJECT_NOT_FOUND, "User not found.");
    }
};

const validateCode = async ({ params: { code } }) => {
    const regCode = await new Parse.Query(RegistrationCode)
        .select(["email", "expires"])
        .equalTo("status", "PENDING")
        .equalTo("code", code)
        .first({ useMasterKey: true });

    // If no regCode found, throw an error
    if (!regCode) {
        throw new Parse.Error(Parse.Error.OBJECT_NOT_FOUND, "Registration code is invalid.");
    }

    // If regCode has expired, throw an error
    const now = new Date();
    if (regCode.get("expires") < now) {
        throw new Parse.Error(Parse.Error.VALIDATION_ERROR, "Registration code has expired.");
    }

    // Otherwise, return the email address
    return regCode.get("email");
};

const checkRegistrationEmailStatus = async ({ user, params: { id } }) => {
    await securityUtils.requireAdmin(user);

    const regCode = await new Parse.Query(RegistrationCode)
        .select(["messageId"])
        .get(id, { useMasterKey: true });

    if (!regCode || !regCode.get("messageId")) {
        throw new Parse.Error(Parse.Error.OBJECT_NOT_FOUND, "No valid email found for this code.");
    }

    return mailer.checkStatus(regCode.get("messageId"));
};

Parse.Cloud.define("listUsers", list);
Parse.Cloud.define("changeUserStatus", changeUserStatus);
Parse.Cloud.define("authorize", authorize);
Parse.Cloud.define("send", send);
Parse.Cloud.define("register", register);
Parse.Cloud.define("validateCode", validateCode);
Parse.Cloud.define("checkRegistrationEmailStatus", checkRegistrationEmailStatus);
