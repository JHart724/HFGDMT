import sgMail from "@sendgrid/mail";

const { SG_API_KEY, SG_FROM_EMAIL, UI_URL } = process.env;

sgMail.setApiKey(SG_API_KEY);

const RegistrationCode = Parse.Object.extend("RegistrationCode");

const MSG_FAILED_EMAIL_INIT = "Failed To Init Email System";
const MSG_FAILED_EMAIL_SEND = "Failed To Send Email";

const _send = async (to, from, templateId, data) => {
    if (!SG_API_KEY) {
        throw new Parse.Error(Parse.Error.INTERNAL_SERVER_ERROR, `${MSG_FAILED_EMAIL_INIT}: Missing SG_API_KEY`);
    }

    try {
        const response = await sgMail.send({
            to,
            from,
            templateId,
            dynamic_template_data: data,
            hideWarnings: true,
        });

        return response?.[0]?.headers?.["x-message-id"] || response?.[0]?.headers?.["X-Message-Id"] || null;
    } catch (error) {
        console.error(MSG_FAILED_EMAIL_SEND, { error, data });
        throw new Parse.Error(Parse.Error.SCRIPT_FAILED, MSG_FAILED_EMAIL_SEND);
    }
};

const sendInvite = async (to, code) => {
    return _send(
        to,
        SG_FROM_EMAIL,
        "d-cc643e79629c479fa6bd84d47791241f",
        { to, link: `${UI_URL}/signup?code=${code}` }
    );
};

const _fetchMessageDetails = async (sgMessageId) => {
    if (!SG_API_KEY) {
        throw new Parse.Error(Parse.Error.INTERNAL_SERVER_ERROR, "Missing SG_API_KEY");
    }

    try {
        const queryUrl = `https://api.sendgrid.com/v3/messages?query=msg_id="${sgMessageId}"`;
        console.warn("[SENDGRID] Fetching event details from:", queryUrl);

        const response = await fetch(queryUrl, {
            method: "GET",
            headers: {
                Authorization: `Bearer ${SG_API_KEY}`,
                "Content-Type": "application/json",
            },
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error("[SENDGRID] API error:", { status: response.status, errorDetails: errorText });
            throw new Parse.Error(Parse.Error.SCRIPT_FAILED, `SendGrid API error: ${response.status}`);
        }

        const data = await response.json();
        return data.messages ?? [];
    } catch (error) {
        console.error("[SENDGRID] Failed to fetch event details:", error);
        throw new Parse.Error(Parse.Error.SCRIPT_FAILED, "Failed to fetch SendGrid event details.");
    }
};

const _cleanEvents = (events) => {
    const uniqueEvents = new Map();

    events.forEach((event) => {
        let eventTime = event.timestamp
            ? (typeof event.timestamp === "number" && event.timestamp < 1e12 ? event.timestamp * 1000 : event.timestamp)
            : event.last_event_time;

        const eventKey = `${event.sg_message_id ?? event.msg_id}-${eventTime}`;

        if (uniqueEvents.has(eventKey)) {
            const existingEvent = uniqueEvents.get(eventKey);
            existingEvent.opens_count = Math.max(existingEvent.opens_count, event.opens_count);
            existingEvent.clicks_count = Math.max(existingEvent.clicks_count, event.clicks_count);
        } else {
            uniqueEvents.set(eventKey, { ...event, timestamp: eventTime });
        }
    });

    return Array.from(uniqueEvents.values()).sort((a, b) =>
        new Date(a.timestamp ?? a.last_event_time) - new Date(b.timestamp ?? b.last_event_time)
    );
};

const webhook = async ({ params: { body } }) => {
    if (!Array.isArray(body) || body.length === 0) {
        console.warn("[SENDGRID] Invalid payload received:", body);
        throw new Parse.Error(Parse.Error.INVALID_JSON, "Invalid payload received.");
    }

    const savePromises = body.map(async (event) => {
        const { sg_message_id } = event;
        if (!sg_message_id) {
            return null;
        }

        const messageIdPrefix = sg_message_id.split(".")[0];

        const regCode = await new Parse.Query(RegistrationCode)
            .equalTo("messageId", messageIdPrefix)
            .first({ useMasterKey: true });

        if (!regCode) {
            return null;
        }

        const messageEvents = regCode.get("messageEvents") ?? [];
        let eventDetails = await _fetchMessageDetails(sg_message_id);

        if (eventDetails.length > 0) {
            eventDetails = eventDetails.map(detail => ({ ...detail, ...event }));
        } else {
            eventDetails.push(event);
        }

        messageEvents.push(...eventDetails);

        return regCode.save({ messageEvents: _cleanEvents(messageEvents) }, { useMasterKey: true });
    });

    try {
        await Promise.all(savePromises);
        return "Events processed successfully.";
    } catch (error) {
        console.error("[SENDGRID] Error processing events:", error);
        throw new Parse.Error(Parse.Error.SCRIPT_FAILED, "Failed to process events.");
    }
};

Parse.Cloud.define("sendgrid", webhook);

export default {
    sendInvite,
};
