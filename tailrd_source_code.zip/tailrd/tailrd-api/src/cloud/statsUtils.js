const Patient = Parse.Object.extend("Patient");
const MedicationHistory = Parse.Object.extend("MedicationHistory");

/**
 * Fetches summary statistics for the dashboard, including patient counts, heart failure classification distribution,
 * medication compliance, and provider compliance metrics.
 *
 * @param {Object} params - The parameters for the function.
 * @param {Parse.User} params.user - The authenticated user requesting the dashboard data.
 * @returns {Promise<Object>} The dashboard statistics including:
 * - `ptCount` (Number of patients)
 * - `hfCounts` (Heart failure classification distribution)
 * - `ptCompliance` (Medication compliance grouped by number of medication classes)
 * - `complianceByRx` (Medication compliance by drug category)
 * - `mdComplianceRatio` (Top discharging physicians based on fully compliant patients)
 * @throws {Parse.Error} If the user does not have an associated organization.
 */
const dashboard = async ({ user }) => {
    const sessionToken = user.getSessionToken();

    // Ensure the user has an associated organization
    let organization = user.get("organization");
    if (!organization) {
        throw new Parse.Error(Parse.Error.OBJECT_NOT_FOUND, "User does not have an associated organization.");
    }

    if (!organization.isDataAvailable()) {
        organization = await organization.fetch({ sessionToken });
    }

    // Fetch all patients in the organization
    const patients = await new Parse.Query(Patient)
        .equalTo("organization", organization)
        .select(["hfClass", "dischargingPhysician"])
        .include("dischargingPhysician")
        .findAll({ batchSize: 500, sessionToken });

    const ptCount = patients.length;

    // Count patients by HF classification (hfClass: 1-4)
    const hfCountsMap = { 1: 0, 2: 0, 3: 0, 4: 0 };
    patients.forEach((patient) => {
        const hfClass = patient.get("hfClass");
        if (hfClass >= 1 && hfClass <= 4) {
            hfCountsMap[hfClass] += 1;
        }
    });

    const hfCounts = Object.entries(hfCountsMap).map(([classLabel, value]) => ({
        label: `Class ${classLabel}`,
        value,
        pct: ptCount > 0 ? Math.round((value / ptCount) * 100) : 0
    }));

    // Track medication compliance distribution
    const ptComplianceMap = {
        "0 Meds": 0,
        "1 Meds": 0,
        "2 Meds": 0,
        "3 Meds": 0,
        "4 Meds": 0
    };

    // Track compliance by drug category
    const complianceByRxMap = {
        RASi: new Set(),
        BB: new Set(),
        MRA: new Set(),
        SGLT2i: new Set()
    };

    // Track compliance by discharging physician
    const mdComplianceMap = new Map();

    if (ptCount > 0) {
        // Fetch medication history for all patients
        const medicationHistories = await new Parse.Query(MedicationHistory)
            .select(["patient", "rx"])
            .include("rx")
            .containedIn("patient", patients)
            .findAll({ batchSize: 500, sessionToken });

        // Map patient IDs to their unique medication classifications
        const patientMedMap = new Map();

        for (const medHistory of medicationHistories) {
            const patientId = medHistory.get("patient").id;
            const medication = medHistory.get("rx");

            if (medication && medication.get("classification")) {
                const classification = medication.get("classification");

                if (!patientMedMap.has(patientId)) {
                    patientMedMap.set(patientId, new Set());
                }
                patientMedMap.get(patientId).add(classification);

                // Track compliance by drug category
                if (["ACEi", "ARB", "ARNI"].includes(classification)) {
                    complianceByRxMap.RASi.add(patientId);
                } else if (classification === "Beta Blocker") {
                    complianceByRxMap.BB.add(patientId);
                } else if (classification === "MRA") {
                    complianceByRxMap.MRA.add(patientId);
                } else if (classification === "SGLT2i") {
                    complianceByRxMap.SGLT2i.add(patientId);
                }
            }
        }

        // Count unique medication classes per patient & track fully compliant patients per physician
        patients.forEach((patient) => {
            const medClasses = patientMedMap.get(patient.id) || new Set();
            const classCount = Math.min(medClasses.size, 4);
            ptComplianceMap[`${classCount} Meds`] += 1;

            // Track full compliance per physician
            if (classCount === 4) {
                const physician = patient.get("dischargingPhysician");
                const physicianName = physician ? `Dr. ${physician.get("name")}` : "Unknown";

                mdComplianceMap.set(physicianName, (mdComplianceMap.get(physicianName) || 0) + 1);
            }
        });
    }

    // Convert medication compliance counts to percentages
    const ptCompliance = Object.entries(ptComplianceMap).map(([label, value]) => ({
        label,
        value,
        pct: ptCount > 0 ? Math.round((value / ptCount) * 100) : 0
    }));

    // Compute complianceByRx as percentage values
    const complianceByRx = Object.entries(complianceByRxMap).map(([category, patientsOnMeds]) => {
        const onMeds = patientsOnMeds.size;
        return {
            category,
            values: [
                ptCount > 0 ? Math.round((onMeds / ptCount) * 100) : 0,
                ptCount > 0 ? Math.round(((ptCount - onMeds) / ptCount) * 100) : 0
            ]
        };
    });

    // Compute physician compliance (Top 6 + "Other")
    let mdComplianceArray = Array.from(mdComplianceMap.entries()).sort((a, b) => b[1] - a[1]);

    let otherTotal = 0;
    if (mdComplianceArray.length > 6) {
        otherTotal = mdComplianceArray.slice(6).reduce((sum, [, count]) => sum + count, 0);
        mdComplianceArray = mdComplianceArray.slice(0, 6);
    }

    const mdComplianceRatio = mdComplianceArray.map(([category, value]) => ({
        category,
        value
    }));

    if (otherTotal > 0) {
        mdComplianceRatio.push({ category: "Other", value: otherTotal });
    }

    return {
        ptCount,
        hfCounts,
        ptCompliance,
        complianceByRx,
        mdComplianceRatio
    };
};

const checkPtStatus = async ({ user, params: { id } }) => {
    const sessionToken = user.getSessionToken();

    const ptMedicationHx = await new Parse.Query(MedicationHistory)
        .select(["rx"])
        .include("rx")
        .equalTo("patient", new Patient({ id }))
        .findAll({ batchSize: 20, sessionToken });

    return {
        RASi: ptMedicationHx.some(med => {
            const classification = med.get("rx")?.get("classification");
            return ["ACEi", "ARB", "ARNI"].includes(classification);
        }),
        BB: ptMedicationHx.some(med => med.get("rx")?.get("classification") === "Beta Blocker"),
        MRA: ptMedicationHx.some(med => med.get("rx")?.get("classification") === "MRA"),
        SGLT2i: ptMedicationHx.some(med => med.get("rx")?.get("classification") === "SGLT2i")
    };
};

Parse.Cloud.define("dashboard", dashboard);
Parse.Cloud.define("checkPtStatus", checkPtStatus);


