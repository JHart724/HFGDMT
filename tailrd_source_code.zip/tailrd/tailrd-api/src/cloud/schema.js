const NO_CLP_ACCESS = {
    get: {},
    find: {},
    count: {},
    create: {},
    update: {},
    delete: {},
    addField: {},
};

const RO_CLP_ACCESS = {
    get: { requiresAuthentication: true },
    find: { requiresAuthentication: true },
    count: { requiresAuthentication: true },
    create: {},
    update: {},
    delete: {},
    addField: {},
};

const AUTHENTICATED_CLP_ACCESS = {
    get: { requiresAuthentication: true },
    find: { requiresAuthentication: true },
    count: { requiresAuthentication: true },
    create: { requiresAuthentication: true },
    update: { requiresAuthentication: true },
    delete: { requiresAuthentication: true },
    addField: {},
};

const defs = [
    {
        className: "_User",
        fields: {
            active: { type: "Boolean", options: {  defaultValue: true, required: true }  },
            organization: { type: "Pointer", targetClass: "Organization", options: { required: false } },
        },
        indexes: null,
        classLevelPermissions: null,
    },
    {
        className: "Organization",
        fields: {
            name: { type: "String", options: { required: true } },
            status: { type: "String", options: { defaultValue: "ACTIVE", required: true } },
            adminRole: { type: "Pointer", targetClass: "_Role" },
            userRole: { type: "Pointer", targetClass: "_Role" },
            createdBy: { type: "Pointer", targetClass: "_User" },
            updatedBy: { type: "Pointer", targetClass: "_User" },
        },
        indexes: {
            IX_org_status: { status: 1 },
        },
        classLevelPermissions: {
            ...RO_CLP_ACCESS,
            create: { "role:ADMIN": true },
            update: { "role:ADMIN": true },
        },
    },
    {
        className: "RegistrationCode",
        fields: {
            code: { type: "String", options: { required: true } },
            email: { type: "String", options: { required: true } },
            sent: { type: "Date", options: { required: true } },
            messageId: { type: "String", options: { required: false } },
            messageEvents: { type: "Array", options: { required: false, defaultValue: [] } },
            organization: { type: "Pointer", targetClass: "Organization", options: { required: false } },
            status: { type: "String", options: { defaultValue: "PENDING", required: true } },
            createdBy: { type: "Pointer", targetClass: "_User" },
            updatedBy: { type: "Pointer", targetClass: "_User" },
        },
        indexes: {
            IX_rc_code: { code: 1 },
            IX_rc_status: { status: 1 },
        },
        classLevelPermissions: {
            ...NO_CLP_ACCESS,
            get: { "role:ADMIN": true },
            find: { "role:ADMIN": true },
            count: { "role:ADMIN": true },
            update: { "role:ADMIN": true },
        },
    },
    {
        className: "Patient",
        fields: {
            organization: { type: "Pointer", targetClass: "Organization" },
            mrn: { type: "String", options: { required: true } },
            ageAtAdmission: { type: "Number", options: { required: true } },
            hfClass: { type: "Number", options: { required: true, defaultValue: 0 } },
            sex: { type: "String", options: { required: true, defaultValue: "Other" } },
            race: { type: "String", options: { required: true, defaultValue: "Other"} },
            insuranceType: { type: "String", options: { required: false } },
            zipCode: { type: "String", options: { required: false } },
            admissionDate: { type: "Date", options: { required: true } },
            dischargeDate: { type: "Date", options: { required: true } },
            dischargeDisposition: { type: "String", options: { required: true } },
            admittingService: { type: "String", options: { required: true } },
            scheduledFollowUp: { type: "Boolean", options: { required: true } },
            followUpType: { type: "String", options: { required: true } },
            followUpTimeframe: { type: "Number", options: { required: true } },
            admittingPhysician: { type: "Pointer", targetClass: "Provider" },
            dischargingPhysician: { type: "Pointer", targetClass: "Provider" },
            consultingCardiologist: { type: "Pointer", targetClass: "Provider" },
            primaryCarePhysician: { type: "Pointer", targetClass: "Provider" },
            createdBy: { type: "Pointer", targetClass: "_User" },
            updatedBy: { type: "Pointer", targetClass: "_User" },
        },
        indexes: {
            IX_patient_admission: { admissionDate: 1 },
            IX_patient_discharge: { dischargeDate: 1 },
        },
        classLevelPermissions: AUTHENTICATED_CLP_ACCESS,
    },
    {
        className: "Medication",
        fields: {
            name: { type: "String", options: { required: true } },          // Generic or Brand Name
            classification: { type: "String", options: { required: true } },         // Generic or Brand Name
            rxCUI: { type: "String", options: { required: false } },        // RxNorm ID
            ndc: { type: "String", options: { required: false } },          // National Drug Code
            description: { type: "String", options: { required: false, defaultValue: "" } },
            createdBy: { type: "Pointer", targetClass: "_User" },
            updatedBy: { type: "Pointer", targetClass: "_User" },
        },
        indexes: {
            IX_md_name: { name: 1 },
            IX_md_classification: { classification: 1, name: 1 },
            IX_md_rxCUI: { rxCUI: 1 },
            IX_md_ndc: { ndc: 1 },
        },
        classLevelPermissions: RO_CLP_ACCESS,
    },
    {
        className: "MedicationHistory",
        fields: {
            patient: { type: "Pointer", targetClass: "Patient" },
            rx: { type: "Pointer", targetClass: "Medication" },
            dose: { type: "Number", options: { required: true } },
            unit: { type: "String", options: { required: true } },
            freq: { type: "String", options: { required: true } },
            startDate: { type: "Date", options: { required: true } },
            endDate: { type: "Date", options: { required: false } },
            createdBy: { type: "Pointer", targetClass: "_User" },
            updatedBy: { type: "Pointer", targetClass: "_User" },
        },
        indexes: {
            IX_md_hx_patient: { patient: 1, startDate: 1 },
            IX_md_hx_rx: { rx: 1, startDate: 1 },
        },
        classLevelPermissions: AUTHENTICATED_CLP_ACCESS,
    },
    {
        className: "Provider",
        fields: {
            name: { type: "String", options: { required: true } },
            employeeId: { type: "String", options: { required: false, defaultValue: "" } },
            npi: { type: "String", options: { required: false, defaultValue: "" } },
            organization: { type: "Pointer", targetClass: "Organization" },
            createdBy: { type: "Pointer", targetClass: "_User" },
            updatedBy: { type: "Pointer", targetClass: "_User" },
        },
        indexes: {
            IX_provider_npi: { npi: 1 },
            IX_provider_name: { name: 1, npi: 1 },
        },
        classLevelPermissions: RO_CLP_ACCESS,
    }
];

const addField = (fieldName, field, schema) => {
    switch (field.type) {
        case "Pointer":
            schema.addPointer(fieldName, field.targetClass, field.options);
            break;
        case "Relation":
            schema.addRelation(fieldName, field.targetClass);
            break;
        default:
            schema.addField(fieldName, field.type, field.options);
    }
};

const getSchema = async (className) => {
    const existingSchemas = await Parse.Schema.all();
    return existingSchemas.find((s) => s.className === className);
};

defs.forEach(async (def) => {
    const {
        className, classLevelPermissions, fields, indexes,
    } = def;

    try {
        const prevSchema = await getSchema(className);
        const isNew = prevSchema == null;

        const schema = new Parse.Schema(className);
        if (!isNew) {
            schema.get();
        }

        if (fields) {
            const fieldNames = Object.keys(fields);
            fieldNames.forEach((fieldName) => {
                if (isNew || prevSchema.fields[fieldName] == null) {
                    addField(fieldName, fields[fieldName], schema);
                }
            });
        }

        if (indexes) {
            const ixNames = Object.keys(indexes);
            ixNames.forEach((ixName) => {
                if (isNew || prevSchema.indexes[ixName] == null) {
                    schema.addIndex(ixName, indexes[ixName]);
                }
            });
        }

        if (classLevelPermissions) {
            schema.setCLP(classLevelPermissions);
        }

        if (isNew) {
            await schema.save();
        } else {
            await schema.update();
        }


        console.log(`Class Initialized: ${className}`, { isNew });
    } catch (error) {

        console.error({ className, error });
        throw new Error(`Class Initialization Failed: ${className}`);
    }
});
