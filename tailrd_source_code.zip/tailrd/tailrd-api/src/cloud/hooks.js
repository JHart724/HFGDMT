import securityUtils from "./securityUtils.js";

const Organization = Parse.Object.extend("Organization");
const Patient = Parse.Object.extend("Patient");

const userLogin = async ({ object }) => {
    const user = object;
    const active = user.get("active");
    const organization = user.get("organization");

    if (!active) {
        throw new Parse.Error(Parse.Error.OTHER_CAUSE, "Your account is not active.");
    }

    if (organization) {
        if (!organization.isDataAvailable()) {
            await organization.fetch({ useMasterKey: true });
        }

        const status = organization.get("status");
        if (status !== "ACTIVE") {
            throw new Parse.Error(Parse.Error.OTHER_CAUSE, "Your organization is not active.");
        }
    } else {
        throw new Parse.Error(Parse.Error.OTHER_CAUSE, "Your organization is not active.");
    }

    await user.save({ isOnline: true }, { useMasterKey: true});
};

const userLogout = ({ object }) => {
    object.get("user").save({ isOnline: false }, { useMasterKey: true});
};

const setUsers = ({ object, user }) => {
    if(user) {
        if (object.get("createdBy") == null) {
            object.set("createdBy", user);
        }
        object.set("updatedBy", user);
    }
};

const validateOrganization = ({ object }) => {
    const needsSecuring = !object.get("adminRole") || !object.get("userRole") || !object.getACL();

    if (needsSecuring) {
        try {
            securityUtils.secureOrganization(object);
        } catch (ex) {
            console.error("Error in validateOrganization function:", ex);
        }
    }
};

/* ORG CHILDREN */
const secureByOrganization = async ({ object, user }) => {
    setUsers({ object, user });
    object.setACL(
        await securityUtils.getParentACL(object.get("organization").id, Organization),
    );
};

/* PT CHILDREN */
const secureByPatient = async ({ object, user }) => {
    setUsers({ object, user });
    object.setACL(
        await securityUtils.getParentACL(object.get("patient").id, Patient),
    );
};

Parse.Cloud.beforeLogin(userLogin);
Parse.Cloud.afterLogout(userLogout);

Parse.Cloud.beforeSave("RegistrationCode", setUsers);
Parse.Cloud.beforeSave("Medication", setUsers);
Parse.Cloud.beforeSave("Patient", secureByOrganization);
Parse.Cloud.beforeSave("Provider", secureByOrganization);
Parse.Cloud.beforeSave("MedicationHistory", secureByPatient);

Parse.Cloud.afterSave("Organization", validateOrganization);
