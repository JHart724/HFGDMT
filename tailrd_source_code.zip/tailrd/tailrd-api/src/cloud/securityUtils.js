const ERROR_ADDING_ROLE = "Failed to add role.";
const ERROR_REMOVING_ROLE = "Failed to removing role.";
const ERROR_GET_ROLE = "Failed to get role.";

const grant = async (user, role) => {
    try {
        role.getUsers().add(user);
        return await role.save(null, { useMasterKey: true });
    } catch (error) {
        console.error(ERROR_ADDING_ROLE, { role, user, error });
        throw new Error(ERROR_ADDING_ROLE);
    }
};

const revoke = async (user, role) => {
    try {
        role.getUsers().remove(user);
        return await role.save(null, { useMasterKey: true });
    } catch (error) {
        console.error(ERROR_REMOVING_ROLE, { role, user, error });
        throw new Error(ERROR_REMOVING_ROLE);
    }
};

const getRole = async (role) => {
    try {
        const roleQuery = new Parse.Query(Parse.Role);
        roleQuery.equalTo("name", role);
        return await roleQuery.first({ useMasterKey: true });
    } catch (error) {
        console.error(ERROR_GET_ROLE, { role, error });
        throw new Error(ERROR_GET_ROLE);
    }

};

const isUserInRole = async ({ user, role }) => {
    let roleObj = role;

    if (!(roleObj instanceof Parse.Role)) {
        roleObj = await getRole(roleObj);
        if (!roleObj) {
            return false;
        }
    }

    const roleRelation = roleObj.getUsers();
    const userQuery = roleRelation.query();
    userQuery.equalTo("objectId", user.id);
    const userResult = await userQuery.first({ useMasterKey: true });
    return !!userResult;
};

const requireAdmin = async (user) => {
    const isAdmin = await isUserInRole({ user, role: "ADMIN"});
    if (!isAdmin) {
        throw new Parse.Error(Parse.Error.OPERATION_FORBIDDEN, "You do not have authority to execute this command.");
    }
};

const secureOrganization = async (org) => {
    try {
        let adminRole = org.get("adminRole");
        let userRole = org.get("userRole");

        // Create adminRole if it doesn't exist
        if (!adminRole) {
            adminRole = await getRole(`org-${org.id}-admin`);
            if (!adminRole) {
                const adminRoleACL = new Parse.ACL();
                adminRoleACL.setPublicReadAccess(false);
                adminRole = new Parse.Role(`org-${org.id}-admin`, adminRoleACL);
                adminRole.set("organization", org);
                await adminRole.save(null, { useMasterKey: true });
            }
        }

        // Create userRole if it doesn't exist
        if (!userRole) {
            userRole = await getRole(`org-${org.id}-user`);
            if (!userRole) {
                const userRoleACL = new Parse.ACL();
                userRoleACL.setPublicReadAccess(false);
                userRole = new Parse.Role(`org-${org.id}-user`, userRoleACL);
                userRole.getRoles().add(adminRole);
                userRole.set("organization", org);
                await userRole.save(null, { useMasterKey: true });
            }
        }

        // Verify roles are valid before using them
        if (!(adminRole instanceof Parse.Role) && typeof adminRole !== "string") {
            console.error("Invalid adminRole:", adminRole);
            throw new Error("adminRole must be a ParseRole or a String");
        }

        if (!(userRole instanceof Parse.Role) && typeof userRole !== "string") {
            console.error("Invalid userRole:", userRole);
            throw new Error("userRole must be a ParseRole or a String");
        }

        // Create Account ACL
        const orgACL = new Parse.ACL();
        orgACL.setPublicReadAccess(false);
        orgACL.setPublicWriteAccess(false);
        orgACL.setRoleReadAccess(adminRole, true);
        orgACL.setRoleWriteAccess(adminRole, true);
        orgACL.setRoleReadAccess("ADMIN", true);
        orgACL.setRoleWriteAccess("ADMIN", true);
        orgACL.setRoleReadAccess(userRole, true);
        orgACL.setRoleWriteAccess(userRole, false);

        // Set the Account ACL
        org.setACL(orgACL);
        org.set("adminRole", adminRole);
        org.set("userRole", userRole);

        // Save the Account with new roles
        await org.save(null, { useMasterKey: true });
    } catch (error) {
        console.error("Failed to secure organization", { account: org, error });
        throw error;
    }
};

const getParentACL = async (parentId, parentType) => {
    const query = new Parse.Query(parentType);
    const parent = await query.get(parentId, { useMasterKey: true });
    return parent.getACL();
};

export default {
    isUserInRole, getParentACL, getRole, secureOrganization, grant, revoke, requireAdmin,
};
