import "./schema.js";
import "./hooks.js";
import "./mailer.js";

import "./statsUtils.js";
import "./userUtils.js";

Parse.Cloud.define("ping", () => "pong");
