const fs = require("fs");
const { parse } = require("csv-parse");
const initializeParse = require("./parseInit");

// Initialize Parse
const Parse = initializeParse();
const Medication = Parse.Object.extend("Medication");

// Function to import medications
async function importMedications() {
    fs.createReadStream("medications.csv")
        .pipe(parse({ columns: true, trim: true }))
        .on("data", async (row) => {
            try {
                const name = row["Name"];
                const classification = row["Class"];

                let medication = await new Parse.Query(Medication).equalTo("name", name).first({ useMasterKey: true });

                if (!medication) {
                    medication = new Medication();
                }

                await medication.save({ name, classification }, { useMasterKey: true });
                console.log(`Saved: ${name}`);
            } catch (error) {
                console.error(`Error saving ${row["Name"]}:`, error);
            }
        })
        .on("end", () => {
            console.log("CSV processing completed.");
        })
        .on("error", (error) => {
            console.error("Error reading CSV:", error);
        });
}

// Run import
importMedications();
