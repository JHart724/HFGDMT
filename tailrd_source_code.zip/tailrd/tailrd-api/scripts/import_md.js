const fs = require("fs");
const { parse } = require("csv-parse");
const initializeParse = require("./parseInit");

// Initialize Parse
const Parse = initializeParse();
const Provider = Parse.Object.extend("Provider");
const Organization = Parse.Object.extend("Organization");

// Set default Organization ID
const ORGANIZATION_ID = "qi5d0WJB0u";

// Function to import physicians
async function importPhysicians() {

    // Create a pointer to the organization
    const organization = new Organization();
    organization.id = ORGANIZATION_ID;

    fs.createReadStream("physicians.csv")
        .pipe(parse({ columns: true, trim: true }))
        .on("data", async (row) => {
            try {
                const employeeId = row["id"];
                const name = row["name"];
                const npi = ""; // Leave NPI blank as per requirement

                // Check if provider already exists
                let provider = await new Parse.Query(Provider)
                    .equalTo("employeeId", employeeId)
                    .equalTo("organization", organization)
                    .first({ useMasterKey: true });

                if (!provider) {
                    provider = new Provider();
                }

                await provider.save(
                    { name, employeeId, npi, organization },
                    { useMasterKey: true }
                );

                console.log(`Saved: Provider ${name} (ID: ${employeeId})`);
            } catch (error) {
                console.error(`Error saving Provider ${row["name"]}:`, error);
            }
        })
        .on("end", () => {
            console.log("CSV processing completed.");
        })
        .on("error", (error) => {
            console.error("Error reading CSV:", error);
        });
}

// Run import
importPhysicians();
