const Parse = require("parse/node");
require("dotenv").config();

function initializeParse() {
    const {
        PORT,
        BASE_URL,
        SERVER_URL,
        MOUNT_POINT,
        APP_ID,
        JAVASCRIPT_KEY,
        MASTER_KEY,
    } = process.env;

    const port = PORT || 1337;
    const mountPoint = MOUNT_POINT || "api";
    const baseURL = BASE_URL || `http://localhost:${port}`;
    const serverURL = SERVER_URL || `${baseURL}/${mountPoint}`;
    const appId = APP_ID || "myAppId";
    const javascriptKey = JAVASCRIPT_KEY || "myJSKey";
    const masterKey = MASTER_KEY || "myMasterKey";

    // Initialize Parse
    Parse.initialize(appId, javascriptKey, masterKey);
    Parse.serverURL = serverURL;

    return Parse;
}

module.exports = initializeParse;
