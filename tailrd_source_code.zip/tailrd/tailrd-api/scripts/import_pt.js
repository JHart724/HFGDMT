const fs = require("fs");
const { parse } = require("csv-parse");
const initializeParse = require("./parseInit");

// Initialize Parse
const Parse = initializeParse();
const Patient = Parse.Object.extend("Patient");
const Provider = Parse.Object.extend("Provider");
const Organization = Parse.Object.extend("Organization");

// Set default Organization ID
const ORGANIZATION_ID = "qi5d0WJB0u";

// Function to preload all providers into a map
async function preloadProviders() {
    const providers = await new Parse.Query(Provider).find({ useMasterKey: true });
    const providerMap = new Map();

    providers.forEach((provider) => {
        providerMap.set(provider.get("employeeId"), provider);
    });

    return providerMap;
}

// Function to parse and import patients
async function importPatients() {
    const providerMap = await preloadProviders();

    // Create a pointer to the organization
    const organization = new Organization();
    organization.id = ORGANIZATION_ID;

    fs.createReadStream("patients.csv")
        .pipe(parse({ columns: true, trim: true }))
        .on("data", async (row) => {
            try {
                const mrn = row["id"];
                const ageAtAdmission = parseInt(row["ageAtAdmission"], 10);
                const hfClass = parseInt(row["hfClass"] ?? 0, 10);
                const sex = row["sex"] || "Other";
                const race = row["race"] || "Other";
                const insuranceType = row["insuranceType"] || null;
                const zipCode = row["zipCode"] || null;
                const admissionDate = new Date(row["admissionDate"]);
                const dischargeDate = new Date(row["dischargeDate"]);
                const dischargeDisposition = row["dischargeDisposition"];
                const admittingService = row["admittingService"];
                const scheduledFollowUp = row["scheduledFollowUp"] === "true" || row["scheduledFollowUp"] === "Yes";
                const followUpType = row["followUpType"];
                const followUpTimeframe = parseInt(row["followUpTimeframe"], 10);

                // Find providers by employeeId from providerMap
                const admittingPhysician = providerMap.get(row["admittingPhysician"]) || null;
                const dischargingPhysician = providerMap.get(row["dischargingPhysician"]) || null;
                const consultingCardiologist = providerMap.get(row["consultingCardiologist"]) || null;
                const primaryCarePhysician = providerMap.get(row["primaryCarePhysician"]) || null;

                // Check if patient already exists
                let patient = await new Parse.Query(Patient)
                    .equalTo("organization", organization)
                    .equalTo("mrn", mrn)
                    .first({ useMasterKey: true });

                if (!patient) {
                    patient = new Patient();
                }

                await patient.save(
                    {
                        organization,
                        mrn,
                        ageAtAdmission,
                        hfClass,
                        sex,
                        race,
                        insuranceType,
                        zipCode,
                        admissionDate,
                        dischargeDate,
                        dischargeDisposition,
                        admittingService,
                        scheduledFollowUp,
                        followUpType,
                        followUpTimeframe,
                        admittingPhysician,
                        dischargingPhysician,
                        consultingCardiologist,
                        primaryCarePhysician,
                    },
                    { useMasterKey: true }
                );

                console.log(`Saved: MRN ${mrn}`);
            } catch (error) {
                console.error(`Error saving MRN ${row["id"]}:`, error);
            }
        })
        .on("end", () => {
            console.log("CSV processing completed.");
        })
        .on("error", (error) => {
            console.error("Error reading CSV:", error);
        });
}

// Run import
importPatients();
