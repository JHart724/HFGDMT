const fs = require("fs");
const { parse } = require("csv-parse");
const initializeParse = require("./parseInit");

// Initialize Parse
const Parse = initializeParse();
const MedicationHistory = Parse.Object.extend("MedicationHistory");
const Patient = Parse.Object.extend("Patient");
const Medication = Parse.Object.extend("Medication");
const Organization = Parse.Object.extend("Organization");

// Set default Organization ID
const ORGANIZATION_ID = "qi5d0WJB0u";

// Relevant medication fields in `patients.csv`
const MEDICATION_FIELDS = [
    "betaBlocker",
    "aceInhibitor",
    "arb",
    "arni",
    "mra",
    "sglt2Inhibitor",
    "loopDiuretic",
];

// Function to preload all patients into a map by MRN
async function preloadPatients() {
    // Create a pointer to the organization
    const organization = new Organization();
    organization.id = ORGANIZATION_ID;


    const patients = await new Parse.Query(Patient)
        .equalTo("organization", organization)
        .findAll({ useMasterKey: true });
    const patientMap = new Map();

    patients.forEach((patient) => {
        patientMap.set(patient.get("mrn"), patient);
    });

    return patientMap;
}

// Function to preload all medications into a map by name
async function preloadMedications() {
    const medications = await new Parse.Query(Medication).findAll({ useMasterKey: true });
    const medicationMap = new Map();

    medications.forEach((med) => {
        medicationMap.set(med.get("name"), med);
    });

    return medicationMap;
}

// Function to load `patients.csv` and create a medication-to-MRN map
async function loadPatientMedications() {
    return new Promise((resolve, reject) => {
        const medToMrnMap = new Map();

        fs.createReadStream("patients.csv")
            .pipe(parse({ columns: true, trim: true }))
            .on("data", (row) => {
                const mrn = row["id"]; // MRN (patient ID)
                MEDICATION_FIELDS.forEach((medField) => {
                    const medicationName = row[medField]?.trim();
                    if (medicationName) {
                        medToMrnMap.set(medicationName, mrn);
                    }
                });
            })
            .on("end", () => {
                resolve(medToMrnMap);
            })
            .on("error", (error) => {
                reject(error);
            });
    });
}

// Function to parse and import medication history
async function importMedicationHistory() {
    const patientMap = await preloadPatients();
    const medicationMap = await preloadMedications();
    const medToMrnMap = await loadPatientMedications();

    fs.createReadStream("medHx.csv")
        .pipe(parse({ columns: true, trim: true }))
        .on("data", async (row) => {
            try {
                const medicationName = row["name"]; // Find Medication by name
                const dose = parseFloat(row["dose"]);
                const freq = row["frequency"];
                const startDate = new Date(row["startDate"]);
                const endDate = row["endDate"] ? new Date(row["endDate"]) : null;

                // Find corresponding MRN using the medication-to-patient mapping
                const mrn = medToMrnMap.get(row["id"]);
                if (!mrn) {
                    console.warn(`Skipping ${medicationName}: No linked patient found.`);
                    return;
                }

                // Find Patient and Medication
                const patient = patientMap.get(mrn) || null;
                const medication = medicationMap.get(medicationName) || null;

                if (!patient) {
                    console.warn(`Skipping MRN ${mrn}: Patient not found.`);
                    return;
                }
                if (!medication) {
                    console.warn(`Skipping Medication ${medicationName}: Not found.`);
                    return;
                }

                // Check if record already exists
                let medHistory = await new Parse.Query(MedicationHistory)
                    .equalTo("patient", patient)
                    .equalTo("rx", medication)
                    .equalTo("startDate", startDate)
                    .first({ useMasterKey: true });

                if (!medHistory) {
                    medHistory = new MedicationHistory();
                }

                await medHistory.save(
                    {
                        patient,
                        rx: medication,
                        dose,
                        unit: "mg", // Assuming mg as the unit, modify if necessary
                        freq,
                        startDate,
                        endDate,
                    },
                    { useMasterKey: true }
                );

                console.log(`Saved: ${medicationName} for MRN ${mrn}`);
            } catch (error) {
                console.error(`Error saving medication history for ${row["name"]}:`, error);
            }
        })
        .on("end", () => {
            console.log("CSV processing completed.");
        })
        .on("error", (error) => {
            console.error("Error reading CSV:", error);
        });
}

// Run import
importMedicationHistory();
