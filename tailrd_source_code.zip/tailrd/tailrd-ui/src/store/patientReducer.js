import {Patient, PatientArray} from "domain";

const initState = {
    active: {
        data: new Patient(),
        isLoading: false,
        isLoaded: false,
    },
    list: {
        data: new PatientArray(),
        isLoading: false,
        hasMore: true,
    },
};

export default function organizationReducer(state = initState, action) {
    const { type, meta, payload } = action;
    switch (type) {
        /** *
         * Get/Set Patient
         ** */
        case "GET_PATIENT_PENDING": {
            return { ...state, active: { ...initState.list, isLoading: true } };
        }

        case "GET_PATIENT_REJECTED": {
            return { ...state, active: { ...initState.list, isLoading: false } };
        }

        case "SET_PATIENT_FULFILLED":
        case "GET_PATIENT_FULFILLED": {
            return {
                ...state, active: { data: new Patient(payload), isLoading: false, isLoaded: true } };
        }

        case "SAVE_PATIENT_FULFILLED": {
            const org = new Patient(payload);
            return {
                active: { data: org, isLoading: false, isLoaded: true },
                list: {...state.list, data: state.list.data.addUpdate(org).sort() },
            };
        }

        /** *
         * List Patients
         ** */
        case "LIST_PATIENT_PENDING": {
            return { ...state, list: { ...state.list, isLoading: true } };
        }

        case "LIST_PATIENT_REJECTED": {
            return { ...state, list: { ...initState.list, isLoading: false, hasMore: false } };
        }

        case "LIST_PATIENT_FULFILLED": {
            return { ...state, list: {
                data: new PatientArray([...state.list.data, ...payload]),
                isLoading: false,
                hasMore: payload.length === meta.limit,
            } };
        }


        /** *
         * Resets
         ** */
        case "CLEAR_PATIENT_PENDING": {
            return { ...state, list: {...initState.list} };
        }

        case 'LOGOUT_PENDING': {
            return { ...initState };
        }

        default: {
            return state;
        }
    }
}
