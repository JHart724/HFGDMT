import ErrorHandlerUtils from 'utils/ErrorHandlerUtils';

import { NoticeArray } from 'domain';

const initState = {
    list: new NoticeArray(),
};

export default function noticeReducer(state = initState, action = {}) {
    const { type, payload } = action;

    if (ErrorHandlerUtils.isError(action)) {
        return ErrorHandlerUtils.process(state, action);
    }

    switch (type) {
        case 'ADD_NOTICE_FULFILLED': {
            const { list } = state;
            return { ...state, list: new NoticeArray(list).add(payload) };
        }

        case 'UPDATE_NOTICE_FULFILLED': {
            const { list } = state;
            return { ...state, list: new NoticeArray(list).update(payload) };
        }

        case 'REMOVE_NOTICE_FULFILLED': {
            const { list } = state;
            return { ...state, list: new NoticeArray(list).remove(payload) };
        }

        case 'CLEAR_NOTICE_FULFILLED': {
            return { ...initState };
        }

        default: {
            return state;
        }
    }
}
