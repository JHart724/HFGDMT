import { applyMiddleware, createStore, combineReducers } from 'redux';
import { createLogger } from 'redux-logger';
import { thunk } from 'redux-thunk';
import promise from 'redux-promise-middleware';

import auth from "./authReducer";
import notice from "./noticeReducer";
import organization from "./organizationReducer";
import patient from "./patientReducer";

const createAppStore = (initialState = {}) => {
    const reducer =  combineReducers({
        auth,
        notice,
        organization,
        patient
    });

    const middleware = applyMiddleware(promise, thunk, createLogger());

    return createStore(reducer, initialState, middleware);
};

export default createAppStore;
