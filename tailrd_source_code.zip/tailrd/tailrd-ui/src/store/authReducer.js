
const initState = {
    me: null,
    authorizations: [],
    isAuthorizing: false,
    isAuthorized: false,
};

export default function authReducer(state = initState, action) {
    const { type, payload } = action;

    switch (type) {
        case 'LOGIN_PENDING': {
            return { ...state, isAuthorizing: true };
        }

        case 'LOGOUT_PENDING':
        case 'LOGIN_REJECTED': {
            return { ...initState };
        }

        case 'RESTORE_FULFILLED':
        case 'LOGIN_FULFILLED': {
            if (!payload) {
                return { ...initState };
            }

            return {
                ...state,
                me: payload,
                isAuthorizing: false,
                isAuthorized: true,
            };
        }

        case 'AUTHORIZE_PENDING': {
            return { ...state, authorizations: [] };
        }

        case 'AUTHORIZE_FULFILLED': {
            return { ...state, authorizations: payload };
        }

        default: {
            return state;
        }
    }
}
