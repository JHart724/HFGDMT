import {Organization, OrganizationArray} from "domain";

const initState = {
    active: {
        data: new Organization(),
        isLoading: false,
        isLoaded: false,
    },
    list: {
        data: new OrganizationArray(),
        isLoading: false,
        isLoaded: false,
    },
};

export default function organizationReducer(state = initState, action) {
    const { type, payload } = action;
    switch (type) {
        /** *
         * Get/Set Organization
         ** */
        case "GET_ORGANIZATION_PENDING": {
            return { ...state, active: { ...initState.list, isLoading: true } };
        }

        case "GET_ORGANIZATION_REJECTED": {
            return { ...state, active: { ...initState.list, isLoading: false } };
        }

        case "SET_ORGANIZATION_FULFILLED":
        case "GET_ORGANIZATION_FULFILLED": {
            return { ...state, active: { data: new Organization(payload), isLoading: false, isLoaded: true } };
        }

        case "SAVE_ORGANIZATION_FULFILLED": {
            const org = new Organization(payload);
            return {
                active: { data: org, isLoading: false, isLoaded: true },
                list: {...state.list, data: state.list.data.addUpdate(org).sort() },
            };
        }

        /** *
         * List Organizations
         ** */
        case "LIST_ORGANIZATION_PENDING": {
            return { ...state, list: { ...initState.list, isLoading: true } };
        }

        case "LIST_ORGANIZATION_REJECTED": {
            return { ...state, list: { ...initState.list, isLoading: false } };
        }

        case "LIST_ORGANIZATION_FULFILLED": {
            return { ...state, list: { data: new OrganizationArray(payload).sort(), isLoading: false, isLoaded: true } };
        }

        default: {
            return state;
        }
    }
}
