import { useDispatch } from 'react-redux';
import {useNavigate} from "react-router-dom";
import {Sheet, Stack} from "@mui/joy";

import authActions from 'actions/authActions';
import ForgotPasswordForm from "components/authorization/ForgotPasswordForm";
import noticeActions from "../../actions/noticeActions";
import {Notice} from "domain";

const ForgotPasswordView = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const handleSubmit = (email) => {
        dispatch(authActions.resert(email)).then(() => {

            dispatch(noticeActions.add({
                title: 'Password Reset Link Sent',
                description: 'Check your email for a link to reset your password.',
                type: Notice.TYPE_SUCCESS
            }));

            navigate('/');
        })
    };

    return (
        <Stack
            alignItems="center"
            justifyContent="center"
            sx={{
                minHeight: '70vh',
                padding: 2
            }}
        >
            <Sheet
                variant="soft"
                sx={{
                    width: '100%',
                    maxWidth: 550,
                    py: 4,
                    px: 3,
                    borderRadius: 'md',
                    backgroundColor: 'white',
                }}
            >
                <ForgotPasswordForm onSubmit={handleSubmit} />
            </Sheet>
        </Stack>

    );
}

ForgotPasswordView.propTypes = {};

export default ForgotPasswordView;
