import { useState } from 'react';
import { useDispatch } from 'react-redux';
import {Sheet, Stack} from "@mui/joy";

import authActions from 'actions/authActions';
import noticeActions from "actions/noticeActions";
import LoginForm from "components/authorization/LoginForm";
import ForgotPasswordForm from "components/authorization/ForgotPasswordForm";
import {Notice} from "domain";

const MODE_LOGIN = 'LOGIN';
const MODE_FP = 'FP';

const LoginView = () => {
    const dispatch = useDispatch();
    const [mode, setMode] = useState(MODE_LOGIN);

    const handleSignIn = (username, password) => {
        event.preventDefault();
        dispatch(authActions.login(username, password));
    };

    const handleGoToForgotPassword = () => {
        setMode(MODE_FP)
    };

    const handleGoToSignIn = () => {
        setMode(MODE_LOGIN)
    };

    const handleSendReset = (email) => {
        dispatch(authActions.requestPasswordReset(email)).then(() => {
            dispatch(noticeActions.add({
                title: 'Password Reset Link Sent',
                description: 'Check your email for a link to reset your password.',
                type: Notice.TYPE_SUCCESS
            }));
            setMode(MODE_LOGIN);
        })
    };

    let content = null;
    if (mode === MODE_FP) {
        content = (
            <ForgotPasswordForm
                onSend={handleSendReset}
                onSignIn={handleGoToSignIn}
            />
        )
    } else {
        content = (
            <LoginForm
                onForgotPassword={handleGoToForgotPassword}
                onSignIn={handleSignIn}
            />
        )
    }

    return (
        <Stack
            alignItems="center"
            justifyContent="center"
            sx={{
                minHeight: '70vh',
                padding: 2
            }}
        >
            <Sheet
                variant="soft"
                sx={{
                    width: '100%',
                    maxWidth: 550,
                    py: 4,
                    px: 3,
                    borderRadius: 'md',
                    backgroundColor: 'white',
                }}
            >
                {content}
            </Sheet>
        </Stack>

    );
}

LoginView.propTypes = {};

export default LoginView;
