import { useDispatch } from "react-redux";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Sheet, Stack, Typography, CircularProgress } from "@mui/joy";

import { Notice } from "domain";
import SignUpForm from "components/authorization/SignUpForm";
import authActions from "actions/authActions";
import noticeActions from "actions/noticeActions";
import { useEffect, useState } from "react";

const SignUpView = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const registrationCode = searchParams.get("code"); // Get `code` from URL query parameters

    const [email, setEmail] = useState("Validating Code...");
    const [isValid, setValid] = useState(null);

    useEffect(() => {
        if (!registrationCode) {
            setValid(false);
            return;
        }

        dispatch(authActions.validateCode(registrationCode))
            .then(({value: validatedEmail}) => {
                setEmail(validatedEmail);
                setValid(true);
            })
            .catch(() => {
                setValid(false);
            });
    }, [registrationCode, dispatch]);

    const handleSignUp = ({ username, password }) => {
        dispatch(authActions.register({ username, registrationCode, password })).then(() => {
            dispatch(
                noticeActions.add({
                    title: "Registration Successful",
                    type: Notice.TYPE_SUCCESS,
                })
            );

            dispatch(authActions.login(username, password)).then(() => {
                navigate("/");
            });
        });
    };

    // **Loading State**
    if (isValid === null) {
        return (
            <Stack alignItems="center" justifyContent="center" sx={{ minHeight: "60vh", padding: 2 }}>
                <CircularProgress />
                <Typography level="body-lg" mt={2}>
                    Validating registration code...
                </Typography>
            </Stack>
        );
    }

    if (isValid === false) {
        return (
            <Stack alignItems="center" justifyContent="center" sx={{ minHeight: "60vh", padding: 2 }}>
                <Typography level="h3" color="danger">
                    Invalid Code
                </Typography>
                <Typography level="body-md">
                    Your registration code is invalid, expired, or has already been used. Please reach out to your account administrator for support or to resend your invitation.
                </Typography>
            </Stack>
        );
    }

    return (
        <Stack alignItems="center" justifyContent="center" sx={{ minHeight: "60vh", padding: 2 }}>
            <Sheet
                variant="soft"
                sx={{
                    width: "100%",
                    maxWidth: 550,
                    py: 4,
                    px: 3,
                    borderRadius: "md",
                    backgroundColor: "white",
                }}
            >
                <SignUpForm onSignUp={handleSignUp} email={email} code={registrationCode} />
            </Sheet>
        </Stack>
    );
};

SignUpView.propTypes = {};

export default SignUpView;
