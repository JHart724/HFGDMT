import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { Stack, Sheet, Typography, IconButton } from "@mui/joy";
import ArrowBackIcon from "@mui/icons-material/KeyboardArrowLeft";

import patientActions from "actions/patientActions";
import PatientTable from "components/patient/PatientTable";
import {PatientQuery} from "domain";
import PatientFilters from "../../components/patient/PatientFilters";

const PAGE_SIZE = 25;

const PatientList = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const patients = useSelector(({ patient }) => patient.list.data);
    const isLoading = useSelector(({ patient }) => patient.list.isLoading);
    const hasMore = useSelector(({ patient }) => patient.list.hasMore);
    const [query, setQuery] = useState(new PatientQuery())

    useEffect(() => () => {
        dispatch(patientActions.clear());
    }, []);

    useEffect(() => {
        dispatch(patientActions.clear()).then(() => {
            dispatch(patientActions.list(query, 0, PAGE_SIZE));
        })
    }, [query]);

    const handleLoadMore = () => {
        if (!isLoading && hasMore) {
            dispatch(patientActions.list(query, patients.length, PAGE_SIZE));
        }
    };

    return (
        <Stack direction="column" spacing={2} py={4}>
            <Stack direction="row" alignItems="center" spacing={1} justifyContent="space-between">
                <Stack direction="row" alignItems="center" spacing={1}>
                    <IconButton
                        variant="plain"
                        color="neutral"
                        size="lg"
                        onClick={() => navigate(-1)}
                    >
                        <ArrowBackIcon />
                    </IconButton>
                    <Typography level="h2" textAlign="left">
                        Patients
                    </Typography>
                </Stack>

                {/* Align PatientFilters to the right */}
                <Stack direction="row" justifyContent="flex-end" flexGrow={1}>
                    <PatientFilters query={query} onChange={setQuery} />
                </Stack>
            </Stack>

            <Sheet sx={{ borderRadius: "md", mt: 2, p: 2 }}>
                <PatientTable
                    patients={patients}
                    onSelect={() => {}}
                    onLoadMore={handleLoadMore}
                    onChange={setQuery}
                    hasMore={hasMore}
                    isLoading={isLoading}
                    query={query}
                />
            </Sheet>
        </Stack>
    );
};

PatientList.propTypes = {};

export default PatientList;
