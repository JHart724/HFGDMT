import {useEffect, useState} from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { IconButton, Stack, Sheet, Typography, CircularProgress } from "@mui/joy";
import ArrowBackIcon from "@mui/icons-material/KeyboardArrowLeft";

import patientActions from "actions/patientActions";
import StatusChip from "components/ui/StatusChip";
import DateUtils from "../../utils/DateUtils";

const DEFAULT_STATUS = {
    RASi: null,
    BB: null,
    MRA: null,
    SGLT2i: null
};

const PatientDetails = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const activePatient = useSelector(({ patient }) => patient.active.data);
    const isLoading = useSelector(({ patient }) => patient.active.isLoading);
    const [status, setStatus] = useState(DEFAULT_STATUS);


    useEffect(() => {
        dispatch(patientActions.checkStatus(id))
            .then((result) => {
                setStatus({ ...DEFAULT_STATUS, ...result.value });
            })
            .catch(() => {
                setStatus(DEFAULT_STATUS);
            });
    }, [dispatch, id]);

    // Check if the ID in the path matches the active patient, and load if needed
    useEffect(() => {
        if (!isLoading && activePatient?.id !== id) {
            dispatch(patientActions.get(id));
        }
    }, [id, activePatient, isLoading, dispatch]);

    return (
        <Stack direction="column" spacing={2} py={4}>
            <Stack direction="row" alignItems="center" spacing={1}>
                <IconButton
                    variant="plain"
                    color="neutral"
                    size="lg"
                    onClick={() => navigate(-1)}
                >
                    <ArrowBackIcon />
                </IconButton>
                <Typography level="h2" textAlign="left">
                    { activePatient ? `MRN #${activePatient?.mrn?.toUpperCase().substring(0, 8)}` : "Patient Details" }
                </Typography>
            </Stack>

            {isLoading ? (
                <Stack justifyContent="center" alignItems="center" py={4}>
                    <CircularProgress />
                </Stack>
            ) : (
                <>
                    <Sheet sx={{ borderRadius: "md", mt: 2, p: 2 }}>
                        <Typography level="h3">Patient Details</Typography>
                        <Stack direction="row" spacing={1} justifyContent="space-between" alignItems="stretch" p={2}>
                            <Stack direction="column" spacing={1} flexGrow={1}>
                                <Typography><strong>Age:</strong> {activePatient?.ageAtAdmission}</Typography>
                                <Typography><strong>Sex:</strong> {activePatient?.sex}</Typography>
                                <Typography><strong>Race:</strong> {activePatient?.race}</Typography>
                                <Typography><strong>HF Class:</strong> {activePatient?.hfClassLabel}</Typography>
                            </Stack>
                            <Stack direction="column" spacing={1} flexGrow={1}>
                                <Typography><strong>Discharging Physician:</strong> {activePatient?.dischargingPhysician ? `Dr. ${activePatient?.dischargingPhysician?.get('name')}` : 'N/A'}</Typography>
                                <Typography><strong>PCP:</strong> {activePatient?.primaryCarePhysician ? `Dr. ${activePatient?.primaryCarePhysician?.get('name')}` : 'N/A'}</Typography>
                                <Typography><strong>Admitting Physician:</strong> {activePatient?.admittingPhysician ? `Dr. ${activePatient?.admittingPhysician?.get('name')}` : 'N/A'}</Typography>
                                <Typography><strong>Consulting Cardiologist:</strong> {activePatient?.consultingCardiologist ? `Dr. ${activePatient?.consultingCardiologist?.get('name')}` : 'N/A'}</Typography>
                            </Stack>
                            <Stack direction="column" spacing={1} flexGrow={1}>
                                <Typography><strong>Last Updated:</strong> {DateUtils.formatDate(activePatient?.updatedAt?.toString())}</Typography>
                                <Typography><strong>Joined Program:</strong> {DateUtils.formatDate(activePatient?.createdAt?.toString())}</Typography>
                            </Stack>
                        </Stack>
                    </Sheet>

                    <Sheet sx={{ borderRadius: "md", mt: 2, p: 2 }}>
                        <Typography level="h3">Compliance</Typography>
                        <Stack direction="row" spacing={1} justifyContent="space-around" alignItems="stretch" py={2}>
                            <StatusChip label="RASi" status={status?.RASi} />
                            <StatusChip label="Beta Blocker" status={status?.BB} />
                            <StatusChip label="MRA" status={status?.MRA} />
                            <StatusChip label="SGLT2i" status={status?.SGLT2i} />
                        </Stack>
                    </Sheet>
                </>
            )}
        </Stack>
    );
};

export default PatientDetails;
