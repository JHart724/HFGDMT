import { useNavigate } from "react-router-dom";
import {Stack, Typography, Box, Button} from "@mui/joy";
import SummeryPanel from "./SummeryPanel";

const DashboardView = () => {
    const navigate = useNavigate();
    return (
        <Stack direction="column" spacing={2} pt={4}>
            <Typography level="h2" textAlign="center">
                Dashboard
            </Typography>
            <SummeryPanel/>
            <Box textAlign="right">
                <Button variant="solid" color="primary" size="lg" onClick={() => navigate("/patient")}>Patient
                    List</Button>
            </Box>
        </Stack>
    );
}

DashboardView.propTypes = {};

export default DashboardView;
