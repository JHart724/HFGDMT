import { useEffect, useState, useLayoutEffect, useRef } from "react";
import { useDispatch } from "react-redux";
import { Sheet, Stack, Typography, Grid } from "@mui/joy";
import PieChart from "components/charts/PieChart";
import StackedChart from "components/charts/StackedChart";
import BarChart from "components/charts/BarChart";

import appActions from "actions/appActions";

const SummeryPanel = () => {
    const dispatch = useDispatch();
    const containerRef = useRef(null);
    const [chartSize, setChartSize] = useState(175);
    const [dashboardData, setDashboardData] = useState(null);

    const updateChartSize = () => {
        if (containerRef.current) {
            const containerWidth = containerRef.current.offsetWidth;
            const newSize = Math.max(175, Math.min(containerWidth * 0.4, 320));
            setChartSize(newSize);
        }
    };

    useLayoutEffect(() => {
        updateChartSize();
    }, []);

    useEffect(() => {
        window.addEventListener("resize", updateChartSize);
        return () => window.removeEventListener("resize", updateChartSize);
    }, []);

    useEffect(() => {
        const fetchDashboardData = async () => {
            try {
                const response = await dispatch(appActions.dashboard());
                setDashboardData(response?.value ?? null);
            } catch {
                setDashboardData(null);
            }
        };

        fetchDashboardData();
    }, [dispatch]);

    let content = <Typography level="body-lg" pt={4} textAlign="center">Loading dashboard data...</Typography>;

    if (dashboardData) {
        const { ptCount, hfCounts, ptCompliance, complianceByRx, mdComplianceRatio } = dashboardData;
        const filteredPtCompliance = (ptCompliance || []).filter(item => item.value > 0);

        content = (
            <Grid
                container
                spacing={2}
                sx={{
                    '--Grid-borderWidth': '1px',
                    '& > div': {
                        borderRight: 'var(--Grid-borderWidth) solid',
                        borderBottom: 'var(--Grid-borderWidth) solid',
                        borderColor: 'divider',
                    },
                    '& > div:nth-of-type(2n)': {
                        borderRight: 'none',
                    },
                    '& > div:nth-last-of-type(-n+2)': {
                        borderBottom: 'none',
                    },
                }}
            >
                {/* HF Counts Chart */}
                <Grid xs={12} sm={6}>
                    <Stack spacing={1} alignItems="center" justifyContent="center">
                        <PieChart data={hfCounts || []} size={chartSize} />
                        <Typography level="body-lg" textAlign="center">{ptCount || 0}</Typography>
                        <Typography level="body-sm" color="neutral" textAlign="center">
                            Patients Discharged With HF
                        </Typography>
                    </Stack>
                </Grid>

                {/* Patient Compliance Pie Chart */}
                <Grid xs={12} sm={6}>
                    <Stack spacing={1} alignItems="center" justifyContent="center">
                        <PieChart data={filteredPtCompliance} size={chartSize} />
                        <Typography level="body-sm" color="neutral" textAlign="center">
                            Pts Fully Compliant
                        </Typography>
                        <Stack direction="row" spacing={1} justifyContent="center" alignItems="baseline">
                            <Typography level="body-lg">
                                {filteredPtCompliance?.find(d => d.label === "4 Meds")?.value || 0}
                            </Typography>
                            <Typography level="body-xs" color="neutral">
                                ({filteredPtCompliance?.find(d => d.label === "4 Meds")?.pct || 0}%)
                            </Typography>
                        </Stack>
                    </Stack>
                </Grid>

                {/* Compliance By Medication Chart */}
                <Grid xs={12} sm={6}>
                    <Stack spacing={1} alignItems="center" justifyContent="center">
                        <StackedChart data={complianceByRx || []} size={chartSize} stacked100={true} />
                        <Typography level="body-sm" color="neutral" textAlign="center">
                            Compliance by Medication
                        </Typography>
                    </Stack>
                </Grid>

                {/* MD Compliance Ratio Bar Chart */}
                <Grid xs={12} sm={6}>
                    <Stack spacing={1} alignItems="center" justifyContent="center">
                        <BarChart data={mdComplianceRatio || []} size={chartSize} fadeLastBar />
                        <Typography level="body-xs" color="neutral" textAlign="center">
                            % of Full Compliance by Discharging Physician
                        </Typography>
                    </Stack>
                </Grid>
            </Grid>
        )
    }

    return (
        <Sheet ref={containerRef} sx={{ borderRadius: "md", p: 2, width: "100%", minHeight: 750 }}>
            {content}
        </Sheet>
    );
};

export default SummeryPanel;
