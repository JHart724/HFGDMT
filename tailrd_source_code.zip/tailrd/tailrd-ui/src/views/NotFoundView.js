import { Container, Box, Alert, Typography, Link } from '@mui/joy';
import WarningIcon from '@mui/icons-material/Warning';

const NotFoundView = () => (
    <Container maxWidth="md">
        <Box sx={{ my: 4 }}>
            <Alert
                startDecorator={
                    <WarningIcon fontSize="xl2" sx={{ mt:0.5, ml:1 }} />
                }
                sx={{ alignItems: 'flex-start', overflow: 'hidden' }}
                variant="soft"
                invertedColors
                color="warning"
            >
                <div>
                    <Typography level="title-lg">
                        Page Not Found
                    </Typography>
                    <Typography level="body-sm">
                        Sorry, this is an unknown page.
                    </Typography>
                </div>
            </Alert>
        </Box>
        <Box sx={{ textAlign: 'center' }}>
            <Link
                href="/"
                level="body-md"
                underline="none"
                variant="plain"
            >
                Return Home
            </Link>
        </Box>
    </Container>
);

NotFoundView.propTypes = {};

export default NotFoundView;
