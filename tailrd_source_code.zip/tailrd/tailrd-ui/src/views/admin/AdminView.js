import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Typography, Sheet, Box } from "@mui/joy";

import organizationActions from "actions/organizationActions";
import useAuth, { AUTH_ROLES } from "hooks/useAuth";
import NotFoundView from "views/NotFoundView";
import {useNavigate} from "react-router-dom";
import OrganizationTable from "components/organization/OrganizationTable";
import AddOrganizationButton from "components/organization/AddOrganizationButton";

const AdminView = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [isSysAdmin] = useAuth([AUTH_ROLES.SYSTEM_ADMIN]);
    const { data: organizations, isLoading, isLoaded} = useSelector(({ organization }) => organization.list );

    useEffect(() => {
        if (!isLoading && !isLoaded) {
            dispatch(organizationActions.list());
        }
    });

    const handleSelect = (org) => {
        dispatch(organizationActions.set(org)).then(() => {
            navigate(`/admin/${org.id}`);
        });
    }

    if (!isSysAdmin) {
        return <NotFoundView />
    }

    return (
        <>
            <Typography level="h2" textAlign="center" mt={4}>
                System Administration
            </Typography>
            <Sheet sx={{ borderRadius: 'md', mt: 2, p: 2 }}>
                <OrganizationTable
                    organizations={organizations}
                    isLoaded={isLoaded}
                    isLoading={isLoading}
                    onSelect={handleSelect}
                />
            </Sheet>
            <Box mt={2} textAlign="right">
                <AddOrganizationButton />
            </Box>
        </>
    );
}

AdminView.propTypes = {};

export default AdminView;
