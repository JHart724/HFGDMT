import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { useDispatch, useSelector } from 'react-redux';
import {Typography, IconButton, Sheet, Box, Button, Switch, Stack, CircularProgress} from '@mui/joy';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import BlockIcon from '@mui/icons-material/Block';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

import organizationActions from 'actions/organizationActions';
import useDispatcher from "hooks/useDispatcher";
import {Organization} from 'domain';
import UserTable from "components/organization/UserTable";
import OrganizationInvitations from "components/organization/OrganizationInvitations";
import useAuth, {AUTH_ROLES} from "../../hooks/useAuth";
import NotFoundView from "../NotFoundView";

const OrgDetailsView = () => {
    const [isSysAdmin] = useAuth([AUTH_ROLES.SYSTEM_ADMIN]);
    const dispatch = useDispatch();
    const dispatcher = useDispatcher();
    const navigate = useNavigate();
    const { id } = useParams();

    const [isViewingActive, setIsViewingActive] = useState(true);
    const [organizationUsers, setOrganizationUsers] = useState([]);

    const { data: organization, isLoading, isLoaded } = useSelector(({ organization }) => organization.active);

    useEffect(() => () => setOrganizationUsers([]), []);

    useEffect(() => {
        if (isSysAdmin) {
            if (id !== organization?.id) {
                dispatch(organizationActions.get(id)).then(() => {
                    fetchOrganizationUsers(id, isViewingActive);
                });
            } else {
                fetchOrganizationUsers(id, isViewingActive);
            }
        }
    }, [id, isViewingActive, isSysAdmin]);

    const fetchOrganizationUsers = (orgId, isActive) => {
        dispatch(organizationActions.listUsers(orgId, isActive))
            .then(({ value: users }) => setOrganizationUsers(users))
            .catch(() => setOrganizationUsers([]));
    };

    const handleDisable = () => {
        organization.set('status', Organization.STATUS_INACTIVE);
        dispatch(organizationActions.save(organization));
    };

    const handleEnable = () => {
        organization.set('status', Organization.STATUS_ACTIVE);
        dispatch(organizationActions.save(organization));
    };

    const handleChangeUser = (updatedUser) => {
        dispatcher(organizationActions.changeUserStatus(updatedUser.id, updatedUser.active), "User Updated.")
            .then(() => {
                setOrganizationUsers((prevUsers) =>
                    prevUsers.map((user) =>
                        user.id === updatedUser.id ? { ...user, active: updatedUser.active } : user
                    )
                );
            });
    };

    const handleToggle = () => {
        setIsViewingActive((prev) => !prev);
    };

    if (isLoading || !isLoaded) {
        return (
            <Stack alignItems="center" justifyContent="center" sx={{ minHeight: "60vh", padding: 2 }}>
                <CircularProgress />
                <Typography level="body-lg" mt={2}>
                    Loading Organization Data...
                </Typography>
            </Stack>
        )
    }

    if (!isSysAdmin) {
        return <NotFoundView />
    }

    return (
        <>
            <Box
                sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 4, p: 2, borderRadius: 'md' }}
            >
                <IconButton onClick={() => navigate(-1)} color="neutral" sx={{ borderRadius: '50%' }}>
                    <ChevronLeftIcon />
                </IconButton>
                <Typography level="h2" sx={{ flex: 1, textAlign: 'center' }}>
                    {organization?.name}
                </Typography>
                {organization?.status === Organization.STATUS_ACTIVE ? (
                    <Button
                        variant="plain"
                        color="warning"
                        startDecorator={<BlockIcon />}
                        onClick={handleDisable}
                    >
                        Disable
                    </Button>
                ) : (
                    <Button
                        variant="solid"
                        color="success"
                        startDecorator={<CheckCircleIcon />}
                        onClick={handleEnable}
                    >
                        Enable
                    </Button>
                )}
            </Box>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }} mt={4}>
                <Typography level="body-sm" sx={{ mr: 1 }}>
                    {isViewingActive ? 'Viewing Active Users' : 'Viewing Inactive Users'}
                </Typography>
                <Switch
                    checked={isViewingActive}
                    onChange={handleToggle}
                    slotProps={{ input: { 'aria-label': 'Toggle active/inactive users' } }}
                />
            </Box>
            <Sheet sx={{ borderRadius: 'md', mt: 2, p: 2 }}>
                <UserTable users={organizationUsers} onChange={handleChangeUser} />
            </Sheet>
            <OrganizationInvitations organization={organization} />
        </>
    );
};

OrgDetailsView.propTypes = {};

export default OrgDetailsView;
