import { useEffect, useState } from "react";
import PropTypes from "prop-types";
import { useInView } from "react-intersection-observer";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import ArrowIcon from "@mui/icons-material/KeyboardArrowRight";

import patientActions from "actions/patientActions";
import PatientTableRowSkeleton from "components/patient/PatientTableRowSkeleton";
import StatusIndicator from "components/ui/StatusIndicator";

const DEFAULT_STATUS = {
    RASi: null,
    BB: null,
    MRA: null,
    SGLT2i: null
};

const PatientTableRow = ({ patient }) => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { ref, inView } = useInView({ threshold: 0 });

    const [status, setStatus] = useState(DEFAULT_STATUS);

    useEffect(() => {
        if (inView) {
            dispatch(patientActions.checkStatus(patient.id))
                .then((result) => {
                    setStatus({ ...DEFAULT_STATUS, ...result.value });
                })
                .catch(() => {
                    setStatus(DEFAULT_STATUS);
                });
        }
    }, [inView, dispatch, patient.id]);

    const handleOpen = () => {
        dispatch(patientActions.set(patient)).then(() => {
            navigate(`/patient/${patient.id}`);
        });
    };

    if (!inView) {
        return <PatientTableRowSkeleton ref={ref} />;
    }

    return (
        <tr ref={ref} onClick={handleOpen} style={{cursor: "pointer"}}>
            <td data-clamp>{patient.mrn.toUpperCase().substring(0, 8)}</td>
            <td>{patient.hfClassLabel}</td>
            <td>{patient.ageAtAdmission}</td>
            <td>{patient.sex}</td>
            <td data-clamp>{patient.dischargingPhysicianName}</td>
            <td data-clamp>{patient.primaryCarePhysicianName}</td>
            <td style={{textAlign: "center"}}><StatusIndicator status={status.RASi}/></td>
            <td style={{textAlign: "center"}}><StatusIndicator status={status.BB}/></td>
            <td style={{textAlign: "center"}}><StatusIndicator status={status.MRA}/></td>
            <td style={{textAlign: "center"}}><StatusIndicator status={status.SGLT2i}/></td>
            <td>
                <ArrowIcon sx={{fontSize: 28}}/>
            </td>
        </tr>
    );
};

PatientTableRow.propTypes = {
    patient: PropTypes.shape({
        id: PropTypes.string.isRequired, // Ensure `id` exists for navigation
        mrn: PropTypes.string.isRequired,
        hfClass: PropTypes.oneOf([1, 2, 3, 4]).isRequired,
        ageAtAdmission: PropTypes.number.isRequired,
        sex: PropTypes.oneOf(["M", "F"]).isRequired,
    }).isRequired,
};

export default PatientTableRow;
