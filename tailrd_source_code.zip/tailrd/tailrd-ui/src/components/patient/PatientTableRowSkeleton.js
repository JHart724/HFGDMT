import { forwardRef } from "react";
import { Skeleton } from "@mui/joy";
import { useTheme } from "@mui/joy/styles"; // Import useTheme hook
import ArrowIcon from "@mui/icons-material/KeyboardArrowRight";
import StatusIndicator from "../ui/StatusIndicator";

const PatientTableRowSkeleton = forwardRef((props, ref) => {
    const theme = useTheme(); // Get the theme from MUI Joy

    return (
        <tr ref={ref} {...props}>
            <td><Skeleton variant="rectangular">12345678</Skeleton></td>
            <td><Skeleton variant="rectangular">0</Skeleton></td>
            <td><Skeleton variant="rectangular">00</Skeleton></td>
            <td><Skeleton variant="rectangular">Other</Skeleton></td>
            <td style={{ textAlign: "center" }}><StatusIndicator /></td>
            <td style={{ textAlign: "center" }}><StatusIndicator /></td>
            <td style={{ textAlign: "center" }}><StatusIndicator /></td>
            <td style={{ textAlign: "center" }}><StatusIndicator /></td>
            <td>
                <ArrowIcon sx={{ fontSize: 28, color: theme.vars.palette.neutral[200] }} />
            </td>
        </tr>
    );
});

PatientTableRowSkeleton.displayName = "PatientTableRowSkeleton";

export default PatientTableRowSkeleton;
