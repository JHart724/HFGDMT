import { useEffect } from "react";
import PropTypes from "prop-types";
import { useInView } from "react-intersection-observer";
import { Table, IconButton } from "@mui/joy";
import { ArrowUpward, ArrowDownward, UnfoldMore } from "@mui/icons-material";

import PatientTableRow from "components/patient/PatientTableRow";
import PatientTableRowSkeleton from "./PatientTableRowSkeleton";
import { PatientQuery } from "domain";

const PatientTable = ({ patients, onSelect, onLoadMore, hasMore, isLoading, query, onChange }) => {
    const { ref, inView } = useInView({ threshold: 0 });

    useEffect(() => {
        if (inView && hasMore) {
            onLoadMore();
        }
    }, [inView, hasMore]);

    const handleSort = (field) => {
        if (!PatientQuery.SORTABLE_FIELDS.includes(field)) return;

        let newDirection;
        if (query.sortBy === field) {
            newDirection = query.sortDirection === PatientQuery.SORT_ASC
                ? PatientQuery.SORT_DESC
                : PatientQuery.SORT_ASC;
        } else {
            newDirection = PatientQuery.SORT_ASC;
        }

        onChange(new PatientQuery(query).sort(field, newDirection));
    };

    const renderSortIcon = (field) => {
        if (!PatientQuery.SORTABLE_FIELDS.includes(field)) return null;
        if (query.sortBy !== field) return <UnfoldMore fontSize={"sm"} />;
        return query.sortDirection === PatientQuery.SORT_ASC ? (
            <ArrowDownward fontSize={"sm"} />
        ) : (
            <ArrowUpward fontSize={"sm"} />
        );
    };

    return (
        <Table aria-label="patient list" stickyHeader hoverRow>
            <thead>
                <tr>
                    {[
                        { label: "MRN", field: PatientQuery.FIELD_MRN },
                        { label: "HF Class", field: PatientQuery.FIELD_HEART_FAILURE_CLASS },
                        { label: "Age", field: PatientQuery.FIELD_AGE },
                        { label: "Sex", field: PatientQuery.FIELD_SEX },
                        { label: "DP", field: PatientQuery.FIELD_DISCHARGING_PHYSICIAN },
                        { label: "PCP", field: PatientQuery.FIELD_PCP },
                    ].map(({ label, field }) => {
                        const isSortable = PatientQuery.SORTABLE_FIELDS.includes(field);
                        return (
                            <th
                                key={field}
                                onClick={isSortable ? () => handleSort(field) : undefined}
                                style={isSortable ? { cursor: "pointer" } : undefined}
                            >
                                {label}
                                {isSortable && (
                                    <IconButton size="sm">
                                        {renderSortIcon(field)}
                                    </IconButton>
                                )}
                            </th>
                        );
                    })}
                    <th style={{ textAlign: "center", width: 75 }}>RASi</th>
                    <th style={{ textAlign: "center", width: 75 }}>BB</th>
                    <th style={{ textAlign: "center", width: 75 }}>MRA</th>
                    <th style={{ textAlign: "center", width: 75 }}>SGLT2i</th>
                    <th style={{ width: "44px" }}>&nbsp;</th>
                </tr>
            </thead>
            <tbody>
                {patients.map((patient) => (
                    <PatientTableRow key={patient.mrn} patient={patient} onSelect={onSelect} />
                ))}
                {hasMore && !isLoading && (
                    <>
                        <PatientTableRowSkeleton ref={ref} />
                        <PatientTableRowSkeleton />
                        <PatientTableRowSkeleton />
                    </>
                )}
                {isLoading && (
                    <>
                        <PatientTableRowSkeleton />
                        <PatientTableRowSkeleton />
                        <PatientTableRowSkeleton />
                    </>
                )}
            </tbody>
        </Table>
    );
};

PatientTable.propTypes = {
    patients: PropTypes.arrayOf(
        PropTypes.shape({
            mrn: PropTypes.string.isRequired,
            hfClass: PropTypes.oneOf([1, 2, 3, 4]).isRequired,
            age: PropTypes.number.isRequired,
            sex: PropTypes.oneOf(["M", "F"]).isRequired,
        })
    ).isRequired,
    onSelect: PropTypes.func.isRequired,
    onLoadMore: PropTypes.func.isRequired,
    hasMore: PropTypes.bool.isRequired,
    isLoading: PropTypes.bool.isRequired,
    query: PropTypes.object.isRequired,
    onChange: PropTypes.func.isRequired,
};

export default PatientTable;
