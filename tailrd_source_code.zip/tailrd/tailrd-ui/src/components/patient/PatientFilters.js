import { useState } from "react";
import {
    IconButton,
    Modal,
    ModalDialog,
    ModalClose,
    Stack,
    Typography,
    Select,
    Option,
    Input,
    Button,
    Chip,
} from "@mui/joy";
import FilterListIcon from "@mui/icons-material/FilterList";
import ChipDelete from '@mui/joy/ChipDelete';

import { PatientQuery } from "domain";

const PatientFilters = ({ query, onChange }) => {
    const [open, setOpen] = useState(false);
    const [selectedField, setSelectedField] = useState("");
    const [filterValue, setFilterValue] = useState(null);
    const [isEditing, setIsEditing] = useState(false);

    const availableFields = PatientQuery.FILTERABLE_FIELDS.filter(field => !(field in query.filters));

    // Opens the modal for adding a new filter
    const handleOpen = () => {
        setIsEditing(false);
        setOpen(true);
        setSelectedField("");
        setFilterValue(null);
    };

    // Opens the modal for editing an existing filter
    const handleEditFilter = (field) => {
        setIsEditing(true);
        setSelectedField(field);
        setFilterValue(query.filters[field] ?? "");
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
        setSelectedField("");
        setFilterValue(null);
        setIsEditing(false);
    };

    const handleAddOrUpdateFilter = () => {
        if (!selectedField) return;
        const newQuery = new PatientQuery(query).add(selectedField, filterValue);
        onChange(newQuery);
        handleClose();
    };

    const handleRemoveFilter = (field) => {
        const newQuery = new PatientQuery(query).remove(field);
        onChange(newQuery);
    };

    const formatFilterValue = (field, value) => {
        const fieldType = PatientQuery.FIELD_TYPE[field];

        if (fieldType === "Number" && typeof value === "object") {
            if (value.min !== undefined && value.max !== undefined) {
                return `${value.min} - ${value.max}`;
            } else if (value.min !== undefined) {
                return `> ${value.min}`;
            } else if (value.max !== undefined) {
                return `< ${value.max}`;
            }
        }

        return value;
    };

    const renderInputField = () => {
        if (!selectedField) return null;
        const fieldType = PatientQuery.FIELD_TYPE[selectedField];

        if (Array.isArray(fieldType)) {
            return (
                <Select
                    value={filterValue}
                    onChange={(e, newValue) => setFilterValue(newValue)}
                    placeholder="Select value"
                >
                    {fieldType.map(option => (
                        <Option key={option} value={option}>
                            {String(option)}
                        </Option>
                    ))}
                </Select>
            );
        } else if (fieldType === "Number") {
            return (
                <Stack direction="row" spacing={1}>
                    <Input
                        type="number"
                        placeholder="Min"
                        value={filterValue?.min || ""}
                        onChange={(e) => setFilterValue({ ...filterValue, min: e.target.value })}
                    />
                    <Input
                        type="number"
                        placeholder="Max"
                        value={filterValue?.max || ""}
                        onChange={(e) => setFilterValue({ ...filterValue, max: e.target.value })}
                    />
                </Stack>
            );
        } else {
            return (
                <Input
                    placeholder="Enter value"
                    value={filterValue ? filterValue.replace(/%/g, "") : ""}
                    onChange={(e) => setFilterValue(`%${e.target.value}%`)}
                />
            );
        }
    };

    return (
        <Stack direction="row" spacing={1} alignItems="center">
            <Stack
                direction="row"
                spacing={1}
                alignItems="right"
                sx={{ flexWrap: 'wrap' }}
            >
                {Object.entries(query.filters).map(([field, value]) => (
                    <Chip
                        key={field}
                        variant="solid"
                        color="success"
                        sx={{ paddingX: 2, paddingY: 1, cursor: "pointer" }}
                        onClick={() => handleEditFilter(field)}
                        endDecorator={
                            <ChipDelete
                                variant="soft"
                                onDelete={() => handleRemoveFilter(field)}
                                sx={(theme) => ({ color: theme.vars.palette.success[500], marginLeft: 1 })}
                            />
                        }
                    >
                        {PatientQuery.FIELD_LABELS[field]}: {formatFilterValue(field, value)}
                    </Chip>
                ))}
            </Stack>

            <IconButton variant="solid" color="primary" size="md" onClick={handleOpen}>
                <FilterListIcon />
            </IconButton>

            <Modal open={open} onClose={handleClose}>
                <ModalDialog>
                    <ModalClose />
                    <Typography level="h4">{isEditing ? "Edit Filter" : "Add Filter"}</Typography>
                    <Stack spacing={2}>
                        <Select
                            value={selectedField}
                            onChange={(e, newValue) => setSelectedField(newValue)}
                            placeholder={availableFields.length === 0 ? "No more filters to add" : "Select field"}
                            disabled={isEditing || availableFields.length === 0}
                        >
                            {isEditing ? (
                                <Option key={selectedField} value={selectedField}>
                                    {PatientQuery.FIELD_LABELS[selectedField]}
                                </Option>
                            ) : availableFields.length > 0 ? (
                                availableFields.map(field => (
                                    <Option key={field} value={field}>
                                        {PatientQuery.FIELD_LABELS[field]}
                                    </Option>
                                ))
                            ) : (
                                <Option value={null} disabled>No available filters</Option>
                            )}
                        </Select>


                        {renderInputField()}

                        <Stack direction="row" spacing={1} justifyContent="flex-end">
                            <Button variant="plain" onClick={handleClose}>Cancel</Button>
                            <Button onClick={handleAddOrUpdateFilter} disabled={!selectedField || filterValue === null}>
                                {isEditing ? "Update" : "Add"}
                            </Button>
                        </Stack>
                    </Stack>
                </ModalDialog>
            </Modal>
        </Stack>
    );
};

export default PatientFilters;
