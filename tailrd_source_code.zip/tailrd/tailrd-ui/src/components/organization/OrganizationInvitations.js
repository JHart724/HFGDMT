import { useEffect, useState } from "react";
import PropTypes from "prop-types";
import { useDispatch } from "react-redux";
import { Box, Stack, Table, Sheet, Button, Typography } from "@mui/joy";
import CancelIcon from "@mui/icons-material/Cancel";
import DeleteIcon from "@mui/icons-material/Delete";
import SendIcon from "@mui/icons-material/Send";

import registrationCodeActions from "actions/registrationCodeActions";
import useDispatcher from "hooks/useDispatcher";
import DateUtils from "utils/DateUtils";
import { RegistrationCode, Organization, RegistrationCodeArray } from "domain";
import InviteButton from "components/organization/InviteButton";
import EmailStatusChip from "components/ui/EmailStatusChip";

const ellipsesStyle = {
    textOverflow: "ellipsis",
    overflow: "hidden",
    whiteSpace: "nowrap",
    maxWidth: 0,
};

const OrganizationInvitations = ({ organization }) => {
    const dispatch = useDispatch();
    const dispatcher = useDispatcher();
    const [invitations, setInvitations] = useState(new RegistrationCodeArray());
    const now = DateUtils.now();

    useEffect(() => () => setInvitations(new RegistrationCodeArray()), []);

    useEffect(() => {
        if (organization?.id) {
            dispatch(registrationCodeActions.list(organization.id))
                .then(({value: invites}) => setInvitations(new RegistrationCodeArray(invites).sort()))
                .catch(() => setInvitations(new RegistrationCodeArray()));
        }
    }, [organization]);

    const handleCancel = (invitation) => {
        dispatch(registrationCodeActions.save(invitation.set("status", RegistrationCode.STATUS_CANCELED))).then(() => {
            setInvitations((prevInvites) => prevInvites.filter((i) => i.id !== invitation.id));
        });
    };

    const handleResend = (invitation) => {
        dispatch(registrationCodeActions.save(invitation.set("status", RegistrationCode.STATUS_RESENT))).then(() => {
            dispatcher(registrationCodeActions.send(invitation.email, organization.id), "Invitation Resent")
                .then(({ value: newRegCode }) => {
                    setInvitations(new RegistrationCodeArray(invitations).remove(invitation).add(newRegCode).sort());
                });
        });
    };

    const handleAdd = (invitation) => {
        setInvitations(new RegistrationCodeArray(invitations).add(invitation).sort());
    };

    const btn = (
        <Box mt={2} textAlign="right">
            <InviteButton organization={organization} onAdd={handleAdd} />
        </Box>
    )

    if (invitations.length === 0) {
        return btn;
    }

    return (
        <Box mt={4}>
            <Typography level="h4" mb={2}>
            Pending Invitations
            </Typography>
            <Sheet sx={{ borderRadius: "md", mt: 2, p: 2 }}>
                <Table aria-label="organization invitations" size="sm">
                    <thead>
                        <tr>
                            <th>Email</th>
                            <th>Sent</th>
                            <th style={{textAlign: "center"}}>Email Status</th>
                            <th style={{width: 100, textAlign: "center"}}>Expires</th>
                            <th style={{width: 230}}>&nbsp;</th>
                        </tr>
                    </thead>
                    <tbody>
                        {invitations.length > 0 ? (
                            invitations.map((invitation) => (
                                <tr key={invitation.id}>
                                    <td style={ellipsesStyle}>{invitation.email}</td>
                                    <td style={ellipsesStyle}>{DateUtils.formatDateTime(invitation.sent)}</td>
                                    <td style={{textAlign: "center"}}><EmailStatusChip invitation={invitation}/></td>
                                    <td style={{textAlign: "center"}}>{invitation.expires > now ? DateUtils.timeTo(invitation.expires) : "expired"}</td>
                                    <td style={{textAlign: "right"}}>
                                        {invitation.expires > now ? (
                                            <Stack direction="row" spacing={1} justifyContent="end">
                                                <Button
                                                    variant="solid"
                                                    color="warning"
                                                    size="sm"
                                                    startDecorator={<CancelIcon/>}
                                                    onClick={() => handleCancel(invitation)}
                                                >
                                                    Cancel
                                                </Button>

                                                <Button
                                                    variant="solid"
                                                    color="success"
                                                    size="sm"
                                                    startDecorator={<SendIcon/>}
                                                    onClick={() => handleResend(invitation)}
                                                >
                                                    Resend
                                                </Button>
                                            </Stack>
                                        ) : (
                                            <Stack direction="row" spacing={1} justifyContent="end">
                                                <Button
                                                    variant="solid"
                                                    color="danger"
                                                    size="sm"
                                                    startDecorator={<DeleteIcon/>}
                                                    onClick={() => handleCancel(invitation)}
                                                >
                                                    Delete
                                                </Button>

                                                <Button
                                                    variant="solid"
                                                    color="success"
                                                    size="sm"
                                                    startDecorator={<SendIcon/>}
                                                    onClick={() => handleResend(invitation)}
                                                >
                                                    Resend
                                                </Button>
                                            </Stack>
                                        )}
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan="3" style={{ textAlign: "center" }}>
                                    No pending invitations.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </Table>
            </Sheet>
            {btn}
        </Box>
    );
};

OrganizationInvitations.propTypes = {
    organization: PropTypes.instanceOf(Organization).isRequired,
};

export default OrganizationInvitations;
