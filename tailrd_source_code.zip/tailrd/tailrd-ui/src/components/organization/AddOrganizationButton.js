import { useState } from 'react';
import Button from '@mui/joy/Button';
import Modal from '@mui/joy/Modal';
import ModalDialog from '@mui/joy/ModalDialog';
import Input from '@mui/joy/Input';
import Stack from '@mui/joy/Stack';
import Typography from '@mui/joy/Typography';
import AddIcon from '@mui/icons-material/Add';

import useDispatcher from "hooks/useDispatcher";
import organizationActions from 'actions/organizationActions';
import {Organization} from "domain";

const AddOrganizationButton = () => {
    const dispatch = useDispatcher();
    const [open, setOpen] = useState(false);
    const [orgName, setOrgName] = useState('');

    const handleOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
        setOrgName('');
    };

    const handleAdd = () => {
        if (orgName.trim() === '') return;

        dispatch(organizationActions.save(new Organization().set('name', orgName)), "Organization Created")
            .then(() => {
                handleClose();
            });
    };

    return (
        <>
            <Button variant="solid" startDecorator={<AddIcon />} onClick={handleOpen}>
                Add
            </Button>
            <Modal open={open} onClose={handleClose}>
                <ModalDialog
                    aria-labelledby="add-organization-title"
                    aria-describedby="add-organization-description"
                >
                    <Typography id="add-organization-title" component="h2">
                        Add Organization
                    </Typography>
                    <Input
                        placeholder="Organization Name"
                        value={orgName}
                        onChange={(e) => setOrgName(e.target.value)}
                        fullWidth
                        required
                        sx={{ my: 2 }}
                    />
                    <Stack direction="row" spacing={1} justifyContent="space-between" mt={2}>
                        <Button variant="text" color="neutral" onClick={handleClose}>
                            Cancel
                        </Button>
                        <Button variant="solid" onClick={handleAdd} disabled={orgName.trim() === ''}>
                            Add
                        </Button>
                    </Stack>
                </ModalDialog>
            </Modal>
        </>
    );
};

AddOrganizationButton.propTypes = {};

export default AddOrganizationButton;
