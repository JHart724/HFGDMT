import PropTypes from "prop-types";
import {Avatar, CircularProgress, Table, Typography} from "@mui/joy";
import BusinessIcon from "@mui/icons-material/Business";
import ArrowIcon from "@mui/icons-material/KeyboardArrowRight";

import {OrganizationArray} from "domain";

const OrganizationTable = ({ organizations, isLoading, isLoaded, onSelect }) => (
    <Table aria-label="orginization list" hoverRow>
        <thead>
            <tr>
                <th style={{ width: '44px' }}>&nbsp;</th>
                <th>Organizations</th>
                <th style={{ width: '44px' }}>&nbsp;</th>
            </tr>
        </thead>
        <tbody>
            {(isLoading || !isLoaded) && (
                <tr>
                    <td colSpan={3}>
                        <CircularProgress color="primary" size="sm" />
                        <Typography level="body-sm" display="inline-block" ml={2}>
                        Loading...
                        </Typography>
                    </td>
                </tr>
            )}
            {organizations.map(org => (
                <tr key={org.id} onClick={() => onSelect(org)} style={{ cursor: "pointer" }}>
                    <td>
                        <Avatar color="primary" variant="solid" size="sm">
                            <BusinessIcon />
                        </Avatar>
                    </td>
                    <td>
                        {org.name}
                    </td>
                    <td>
                        <ArrowIcon />
                    </td>
                </tr>
            ))}
        </tbody>
    </Table>
);

OrganizationTable.propTypes = {
    organizations: PropTypes.instanceOf(OrganizationArray).isRequired,
    isLoading: PropTypes.bool.isRequired,
    isLoaded: PropTypes.bool.isRequired,
    onSelect: PropTypes.func.isRequired,
};

export default OrganizationTable;
