import { useState } from "react";
import { Modal, ModalDialog, Button, Input, Stack, Typography } from "@mui/joy";
import AddIcon from "@mui/icons-material/Add";

import useDispatcher from "hooks/useDispatcher";
import registrationCodeActions from "actions/registrationCodeActions";
import PropTypes from "prop-types";
import {Organization} from "domain";

const InviteButton = ({ organization, onAdd }) => {
    const dispatcher = useDispatcher();
    const [open, setOpen] = useState(false);
    const [email, setEmail] = useState("");

    const handleOpen = () => setOpen(true);
    const handleClose = () => {
        setOpen(false);
        setEmail("");
    };

    const handleInvite = () => {
        if (!email.trim()) return;

        dispatcher(registrationCodeActions.send(email, organization.id), "Invitation Sent")
            .then(({ value: newRegCode }) => {
                onAdd(newRegCode);
                handleClose();
            });
    };

    return (
        <>
            <Button variant="solid" startDecorator={<AddIcon />} onClick={handleOpen}>
                Invite User
            </Button>
            <Modal open={open} onClose={handleClose}>
                <ModalDialog aria-labelledby="invite-user-title" aria-describedby="invite-user-description">
                    <Typography id="invite-user-title" component="h2">
                        Invite User
                    </Typography>
                    <Input
                        placeholder="User Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        fullWidth
                        required
                        sx={{ my: 2 }}
                    />
                    <Stack direction="row" spacing={1} justifyContent="space-between" mt={2}>
                        <Button variant="text" color="neutral" onClick={handleClose}>
                            Cancel
                        </Button>
                        <Button variant="solid" onClick={handleInvite} disabled={!email.trim()}>
                            Send Invite
                        </Button>
                    </Stack>
                </ModalDialog>
            </Modal>
        </>
    );
};

InviteButton.propTypes = {
    organization: PropTypes.instanceOf(Organization).isRequired,
    onAdd: PropTypes.func.isRequired,
};

export default InviteButton;
