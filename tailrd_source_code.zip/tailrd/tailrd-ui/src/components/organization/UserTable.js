import { Button, Table } from "@mui/joy";
import DateUtils from "utils/DateUtils";
import PropTypes from "prop-types";
import DeleteIcon from "@mui/icons-material/Delete";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";

const UserTable = ({ users, onChange }) => (
    <Table aria-label="organization users" size="sm">
        <thead>
            <tr>
                <th>Email</th>
                <th style={{ width: '148px' }}>Created</th>
                <th style={{ width: '148px' }}>Last Updated</th>
                <th style={{ width: '148px' }}>&nbsp;</th>
            </tr>
        </thead>
        <tbody>
            {users.length > 0 ? (
                users.map((user) => (
                    <tr key={user.id}>
                        <td data-clamp>{user.email}</td>
                        <td data-clamp>{DateUtils.formatDate(user.createdAt)}</td>
                        <td data-clamp>{DateUtils.formatDate(user.updatedAt)}</td>
                        <td style={{ textAlign: "right" }}>
                            <Button
                                variant="solid"
                                size="sm"
                                color={user.active ? "danger" : "success"}
                                startDecorator={user.active ? <DeleteIcon /> : <CheckCircleIcon />}
                                onClick={() => {
                                    onChange({ ...user, active: !user.active });
                                }}
                            >
                                {user.active ? "Deactivate" : "Activate"}
                            </Button>
                        </td>
                    </tr>
                ))
            ) : (
                <tr>
                    <td colSpan="4" style={{ textAlign: 'center' }}>
                    No users found.
                    </td>
                </tr>
            )}
        </tbody>
    </Table>
);

UserTable.propTypes = {
    users: PropTypes.array.isRequired,
    onChange: PropTypes.func.isRequired,
};

export default UserTable;
