import { useEffect, useRef } from "react";
import { useTheme } from "@mui/material/styles";
import * as d3 from "d3";

/**
 * StackedChart component for rendering stacked bar charts (optionally 100% stacked).
 *
 * @param {Object} props
 * @param {Array} props.data - Array of objects with category and values.
 * @param {number} props.size - Size of the chart (width & height).
 * @param {boolean} props.stacked100 - Whether to render as a 100% stacked chart.
 * @param {Array} props.colors - Array of colors for stack sections.
 * @returns {JSX.Element}
 *
 * Expected data format:
 * [
 *   { category: "Category A", values: [10, 20, 30] },
 *   { category: "Category B", values: [15, 25, 5] },
 * ]
 */
const StackedChart = ({ data, size = 180, stacked100 = false }) => {
    const svgRef = useRef();
    const theme = useTheme();

    const colors = theme.palette.chart;

    useEffect(() => {
        if (!data || data.length === 0) return;

        // Clear previous chart
        d3.select(svgRef.current).selectAll("*").remove();

        // Set margins
        const margin = { top: 10, right: 10, bottom: 30, left: 10 };
        const width = size - margin.left - margin.right;
        const height = size - margin.top - margin.bottom;

        // Create SVG container
        const svg = d3.select(svgRef.current)
            .attr("width", size)
            .attr("height", size)
            .append("g")
            .attr("transform", `translate(${margin.left},${margin.top})`);

        // Prepare data for stacking
        const categories = data.map(d => d.category);
        const stack = d3.stack().keys(d3.range(data[0].values.length));

        let stackedData;
        if (stacked100) {
            stackedData = stack(
                data.map(d => {
                    const total = d3.sum(d.values);
                    return {
                        category: d.category,
                        ...d.values.map(v => (v / total) * 100)
                    };
                })
            );
        } else {
            stackedData = stack(
                data.map(d => ({
                    category: d.category,
                    ...d.values
                }))
            );
        }

        // Set up scales
        const x = d3.scaleBand()
            .domain(categories)
            .range([0, width])
            .padding(0.05);

        const yMax = stacked100 ? 100 : d3.max(data, d => d3.sum(d.values));
        const y = d3.scaleLinear()
            .domain([0, yMax])
            .nice()
            .range([height, 0]);

        // Draw stacked bars
        svg.append("g")
            .selectAll("g")
            .data(stackedData)
            .enter()
            .append("g")
            .attr("fill", (d, i) => colors[i % colors.length])
            .selectAll("rect")
            .data(d => d)
            .enter()
            .append("rect")
            .attr("x", d => x(d.data.category))
            .attr("y", d => y(d[1]))
            .attr("height", d => y(d[0]) - y(d[1]))
            .attr("width", x.bandwidth());

        // Add X-axis labels
        svg.append("g")
            .attr("transform", `translate(0,${height})`)
            .call(d3.axisBottom(x).tickSize(0))
            .selectAll("text")
            .style("text-anchor", "middle")
            .style("font-size", "10px");

    }, [data, size, stacked100]);

    return <svg ref={svgRef} width={size} height={size}></svg>;
};

export default StackedChart;
