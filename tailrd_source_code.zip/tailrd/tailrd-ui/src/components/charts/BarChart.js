import { useEffect, useRef } from "react";
import { useTheme } from "@mui/material/styles";
import * as d3 from "d3";

/**
 * BarChart component for rendering a standard unstacked bar chart.
 *
 * @param {Object} props
 * @param {Array} props.data - Array of objects with category and value.
 * @param {number} props.size - Size of the chart (width & height).
 * @param {string} props.barColor - Color for bars (default: steel blue).
 * @param {boolean} props.grayLastBar - Whether the last bar should be faded out a bit.
 * @returns {JSX.Element}
 *
 * Expected data format:
 * [
 *   { category: "Category A", value: 30 },
 *   { category: "Category B", value: 45 },
 *   { category: "Category C", value: 25 },
 * ]
 */
const BarChart = ({ data, size = 180, fadeLastBar = false }) => {
    const svgRef = useRef();
    const theme = useTheme();

    useEffect(() => {
        if (!data || data.length === 0) return;

        // Clear previous chart
        d3.select(svgRef.current).selectAll("*").remove();

        // Set margins (more left & bottom margin for angled labels)
        const margin = { top: 10, right: 10, bottom: 60, left: 20 };
        const width = size - margin.left - margin.right;
        const height = size - margin.top - margin.bottom;

        // Create SVG container
        const svg = d3.select(svgRef.current)
            .attr("width", size)
            .attr("height", size)
            .append("g")
            .attr("transform", `translate(${margin.left},${margin.top})`);

        // Set up scales
        const x = d3.scaleBand()
            .domain(data.map(d => d.category))
            .range([0, width])
            .padding(0.1);

        const y = d3.scaleLinear()
            .domain([0, d3.max(data, d => d.value)])
            .nice()
            .range([height, 0]);

        // Draw bars
        svg.selectAll(".bar")
            .data(data)
            .enter()
            .append("rect")
            .attr("class", "bar")
            .attr("x", d => x(d.category))
            .attr("y", d => y(d.value))
            .attr("width", x.bandwidth())
            .attr("height", d => height - y(d.value))
            .attr("fill", (d, i) => (fadeLastBar && i === data.length - 1 ? theme.palette.neutral['300'] : theme.palette.chart[0]));

        // Add X-axis with rotated labels
        const xAxis = svg.append("g")
            .attr("transform", `translate(0,${height})`)
            .call(d3.axisBottom(x).tickSize(0));

        xAxis.selectAll("text")
            .attr("dy", "0.5em")
            .attr("dx", "-0.5em")
            .style("text-anchor", "end")
            .style("font-size", "10px")
            .attr("transform", "rotate(-45)")
            .text(d => (d.length > 12 ? `${d.substring(0, 11)}...` : d));

    }, [data, size, fadeLastBar]);

    return <svg ref={svgRef} width={size} height={size}></svg>;
};

export default BarChart;
