import { useEffect, useRef } from "react";
import { useTheme } from '@mui/material/styles';
import * as d3 from "d3";

const PieChart = ({ data, size = 180 }) => {
    const svgRef = useRef();
    const theme = useTheme();

    useEffect(() => {
        if (!data || data.length === 0) return;

        // Calculate dimensions that will ensure labels fit
        const radius = size / 2 * 0.80; // Reduce the radius to leave more room for labels
        const colorOrdinal = d3.scaleOrdinal(theme.palette.chart);

        const pie = d3.pie().sort(null).value(d => d.value);

        // Solid pie chart (no inner radius)
        const arc = d3.arc()
            .outerRadius(radius)
            .innerRadius(0); // Set to 0 for solid pie

        const outerArc = d3.arc()
            .innerRadius(radius * 0.9)
            .outerRadius(radius * 0.9);

        const svg = d3.select(svgRef.current)
            .attr("width", size)
            .attr("height", size)
            .html("") // Clear previous contents
            .append("g")
            .attr("transform", `translate(${size / 2},${size / 2})`);

        const slices = svg.append("g").attr("class", "slices");
        const labels = svg.append("g").attr("class", "labels");
        const lines = svg.append("g").attr("class", "lines");

        const pieData = pie(data);

        // Compute midAngle to correctly position labels
        const midAngle = d => d.startAngle + (d.endAngle - d.startAngle) / 2;

        // Pie slices
        slices.selectAll("path")
            .data(pieData)
            .enter()
            .append("path")
            .attr("d", arc)
            .attr("fill", d => colorOrdinal(d.data.label))
            .attr("stroke", "#fff")
            .style("stroke-width", "2px");

        // Create label groups for multi-line text
        const labelGroups = labels.selectAll("g")
            .data(pieData)
            .enter()
            .append("g")
            .attr("transform", d => {
                const pos = outerArc.centroid(d);
                // Reduce label distance to keep within bounds
                const labelDistance = radius;
                pos[0] = labelDistance * (midAngle(d) < Math.PI ? 1 : -1);
                return `translate(${pos})`;
            });

        // Add white background rectangles for labels
        labelGroups.append("rect")
            .attr("x", d => (midAngle(d) < Math.PI ? 0 : -60))
            .attr("y", -12)
            .attr("width", 60)
            .attr("height", 20)
            .style("fill", "#f7f7f7");

        // Add first line of text (label)
        labelGroups.append("text")
            .attr("dy", "-.2em")
            .style("text-anchor", d => (midAngle(d) < Math.PI ? "start" : "end"))
            .style("font-size", "8px")
            .style("fill", "#333")
            .text(d => {
                // Shorten text if needed
                return d.data.label.length > 10 ?
                    d.data.label.substring(0, 9) + "..." :
                    d.data.label;
            });

        // Add second line of text (percentage)
        labelGroups.append("text")
            .attr("dy", ".8em")
            .style("text-anchor", d => (midAngle(d) < Math.PI ? "start" : "end"))
            .style("font-size", "8px")
            .style("fill", "#333")
            .style("font-weight", "bold")
            .text(d => `${d.data.pct}%`);

        // Conditional connector lines - only draw if distance threshold is met
        lines.selectAll("polyline")
            .data(pieData)
            .enter()
            .append("polyline")
            .attr("points", d => {
                const outerArcCentroid = outerArc.centroid(d);
                const labelPos = outerArc.centroid(d);
                const labelDistance = radius;
                labelPos[0] = labelDistance * (midAngle(d) < Math.PI ? 1 : -1);

                return [outerArcCentroid, labelPos];
            })
            .style("opacity", d => {
                // Calculate distance between slice and label
                const outerArcCentroid = outerArc.centroid(d);
                const labelPos = outerArc.centroid(d);
                labelPos[0] = radius * (midAngle(d) < Math.PI ? 1 : -1);
                const dx = labelPos[0] - outerArcCentroid[0];
                const dy = labelPos[1] - outerArcCentroid[1];
                const distance = Math.sqrt(dx * dx + dy * dy);

                // Only display line if its more then 24px long
                return distance > 24 ? 1 : 0;
            })
            .style("stroke", "black")
            .style("stroke-width", "0.5px")
            .style("fill", "none");

    }, [data, size]);

    return <svg ref={svgRef} width={size} height={size}></svg>;
};

export default PieChart;
