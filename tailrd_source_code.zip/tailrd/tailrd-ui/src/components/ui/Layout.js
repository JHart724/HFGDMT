import { Outlet, Link } from 'react-router-dom';
import Notices from "./Notices";
import Loader from "./Loader";
import MainMenu from "./MainMenu";
import {Box} from "@mui/joy";

const Layout = () => (
    <Box sx={{
        position: 'relative',
        margin: 'auto',
        width: '100%',
        minWidth: 800,
        maxWidth: 1200
    }}>
        <Loader />
        <Link to="/">
            <Box
                component="img"
                src="img/logo.png"
                alt="Logo"
                sx={{
                    height: 63,
                    position: 'relative',
                }}
            />
        </Link>
        <MainMenu />
        <Outlet />
        <Notices />
    </Box>
);

Layout.propTypes = {};

export default Layout;
