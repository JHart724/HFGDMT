import PropTypes from "prop-types";
import { styled } from "@mui/joy/styles";

const SIZE_MAP = {
    sm: 12,  // Small
    md: 18,  // Medium (default)
    lg: 28,  // Large
};

const StatusIndicator = styled("div")(({ theme, status, size = "md" }) => {
    const diameter = SIZE_MAP[size] || SIZE_MAP.md;

    let color;
    if (status === true) {
        color = theme.vars.palette.success[500]; // Green
    } else if (status === false) {
        color = theme.vars.palette.danger[500]; // Red
    } else {
        color = theme.vars.palette.neutral[200]; // Grey (Disabled)
    }

    return {
        width: `${diameter}px`,
        height: `${diameter}px`,
        borderRadius: "50%",
        backgroundColor: color,
        boxShadow: `0 0 ${diameter / 3}px ${color}, inset 0 0 ${diameter / 4}px ${theme.vars.palette.neutral[900]}`,
        display: "inline-block",
    };
});

const StatusIndicatorWrapper = ({ status, size }) => <StatusIndicator status={status} size={size} />;

StatusIndicatorWrapper.propTypes = {
    status: PropTypes.oneOf([true, false, null]), // Can be true, false, or null
    size: PropTypes.oneOf(["sm", "md", "lg"]), // Supports sm, md, lg
};

StatusIndicatorWrapper.defaultProps = {
    size: "md",
};

export default StatusIndicatorWrapper;
