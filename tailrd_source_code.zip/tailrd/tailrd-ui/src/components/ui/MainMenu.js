import {useDispatch} from "react-redux";
import { useNavigate } from "react-router-dom";
import Box from '@mui/joy/Box';
import Menu from '@mui/joy/Menu';
import MenuItem from '@mui/joy/MenuItem';
import ListItemDecorator from '@mui/joy/ListItemDecorator';
import ListDivider from '@mui/joy/ListDivider';
import MenuButton from '@mui/joy/MenuButton';
import Dropdown from '@mui/joy/Dropdown';
import Avatar from '@mui/joy/Avatar';
import Chip from '@mui/joy/Chip';
import Typography from '@mui/joy/Typography';
import LogoutIcon from '@mui/icons-material/Logout';
import MenuIcon from '@mui/icons-material/Menu';
import SysAdminIcon from '@mui/icons-material/AdminPanelSettings';
import AdminIcon from '@mui/icons-material/SupervisedUserCircle';
import UserIcon from '@mui/icons-material/AccountCircle';

import useAuth, { AUTH_ROLES } from "hooks/useAuth";

import authActions from "actions/authActions";
import noticeActions from "actions/noticeActions";
import { Notice } from 'domain';

const MainMenu = () => {
    const { me, isAuthorized, authorizations, hasRole } = useAuth();
    const isAdmin = hasRole(AUTH_ROLES.SYSTEM_ADMIN);
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const handleSignOut = () => {
        dispatch(authActions.logout()).then(() => {
            dispatch(noticeActions.add({title: 'Signed Out', type: Notice.TYPE_SUCCESS}));
        });
    };

    const gotoAdmin = () => {
        navigate('/admin');
    }

    if (!isAuthorized) {
        return null;
    }

    const username = me?.get('username') ?? me?.get('email') ?? '??'
    const avatarLetter = username.charAt(0)?.toUpperCase();
    const authDetails = authorizations.map(auth => {
        switch (auth) {
            case AUTH_ROLES.SYSTEM_ADMIN:
                return {id: auth, label: "System Admin", color: "danger", icon: <SysAdminIcon />};
            case AUTH_ROLES.ADMIN:
                return {id: auth, label: "Administrator", color: "warning", icon: <AdminIcon />};
            case AUTH_ROLES.USER:
                return {id: auth, label: "User", color: "primary", icon: <UserIcon />};
            default:
                return {id: auth, label: auth, color: "neutral", icon: <UserIcon />};
        }
    });

    return (
        <Box
            sx={{
                position: 'absolute',
                top: 6,
                right: 6,
                zIndex: 1100,
            }}
        >
            <Dropdown>
                <MenuButton
                    variant="soft"
                    color="primary"
                >
                    <MenuIcon color="primary" fontSize="large" />
                </MenuButton>
                <Menu placement="bottom-end">
                    <Box
                        sx={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: 1.5,
                            p: 2,
                            minWidth: 240,
                            maxWidth: 500,
                        }}
                    >
                        <Avatar size="sm">{avatarLetter}</Avatar>
                        <Box>
                            <Typography level="title-sm" fontWeight="bold">
                                {username || '--'}
                            </Typography>
                            <Typography level="body-xs">
                                {me?.get('email') || ''}
                            </Typography>
                            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mt: 1 }}>
                                {authDetails.map(auth => (
                                    <Chip
                                        key={auth.id}
                                        variant="solid"
                                        color={auth.color}
                                        startDecorator={auth.icon}
                                    >
                                        {auth.label}
                                    </Chip>
                                ))}
                            </Box>
                        </Box>
                    </Box>
                    <ListDivider />
                    {isAdmin && (
                        <MenuItem onClick={gotoAdmin}>
                            <ListItemDecorator>
                                <SysAdminIcon />
                            </ListItemDecorator>
                            {' Manage System'}
                        </MenuItem>
                    )}
                    <MenuItem onClick={handleSignOut}>
                        <ListItemDecorator>
                            <LogoutIcon />
                        </ListItemDecorator>
                        {' Sign out'}
                    </MenuItem>
                </Menu>
            </Dropdown>
        </Box>
    );
}

MainMenu.propTypes = {};

export default MainMenu;
