import { useSelector } from 'react-redux';
import { Outlet } from 'react-router-dom';
import LoginView from "views/unauthorized/LoginView";

const Authorize = () => {
    const isAuthorized = useSelector(({ auth }) => auth.isAuthorized);

    if (!isAuthorized) {
        return <LoginView />
    }

    return (
        <Outlet/>
    );
}

Authorize.propTypes = {};

export default Authorize;
