import PropTypes from 'prop-types';
import { Stack, Typography } from "@mui/joy";
import Chip from "@mui/joy/Chip";

const StatusChip = ({ label, status, size }) => (
    <Stack textAlign="center">
        <Typography>{label}</Typography>
        <Chip
            variant="solid"
            color={status ? "success" : "danger"}
            sx={{ paddingX: status ? 5 : 2 }}
            size={size}
        >
            {status ? "COMPLIANT" : "NON-COMPLIANT"}
        </Chip>
    </Stack>
);

StatusChip.propTypes = {
    label: PropTypes.string.isRequired,
    status: PropTypes.oneOf([true, false, null]),
    size: PropTypes.oneOf(["sm", "md", "lg"]),
};

StatusChip.defaultProps = {
    status: null,
    size: "md",
};

export default StatusChip;
