import { useEffect } from 'react';
import { useDispatch, useSelector } from "react-redux";

import authActions from 'actions/authActions';

const Loader = () => {
    const dispatch = useDispatch();
    const isAuthorized = useSelector(({ auth }) => auth.isAuthorized);

    useEffect(() => {
        dispatch(authActions.restore());
    });

    useEffect(() => {
        if (isAuthorized) {
            dispatch(authActions.authorize());
        }
    }, [isAuthorized, dispatch]);

    return null;
}

Loader.propTypes = {};

export default Loader;
