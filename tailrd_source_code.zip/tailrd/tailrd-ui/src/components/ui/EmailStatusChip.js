import { useState } from "react";
import PropTypes from "prop-types";
import { Modal, ModalDialog, Typography, Sheet, Table } from "@mui/joy";
import Chip from "@mui/joy/Chip";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import VisibilityIcon from "@mui/icons-material/Visibility";
import MouseIcon from "@mui/icons-material/Mouse";
import SyncIcon from "@mui/icons-material/Sync";
import DateUtils from "../../utils/DateUtils";

// Define status colors
const statusColors = {
    delivered: "success",
    open: "success",
    opened: "success",
    clicked: "warning",
    bounced: "danger",
    dropped: "danger",
    failed: "danger",
    processing: "primary",
    processed: "primary",
    default: "neutral"
};

// Define status icons
const statusIcons = {
    delivered: <CheckCircleIcon />,
    open: <VisibilityIcon />,
    opened: <VisibilityIcon />,
    clicked: <MouseIcon />,
    bounced: <ErrorOutlineIcon />,
    dropped: <ErrorOutlineIcon />,
    failed: <ErrorOutlineIcon />,
    processing: <SyncIcon />,
    processed: <SyncIcon />,
    default: <InfoOutlinedIcon />
};

const EmailStatusChip = ({ invitation }) => {
    const [open, setOpen] = useState(false);
    const messageEvents = invitation?.messageEvents || [];
    const latestEvent = messageEvents.length > 0 ? messageEvents[messageEvents.length - 1] : null;

    if (!latestEvent) {
        return <Chip variant="outlined" color="neutral" disabled startDecorator={<InfoOutlinedIcon />}>Pending</Chip>;
    }

    const latestStatus = latestEvent.event ?? latestEvent.status;
    const statusColor = statusColors[latestStatus] || statusColors.default;
    const statusIcon = statusIcons[latestStatus] || statusIcons.default;

    return (
        <>
            <Chip
                color={statusColor}
                startDecorator={statusIcon}
                onClick={() => setOpen(true)}
                sx={{ cursor: "pointer", px: 2, textTransform: "capitalize" }}
            >
                {latestStatus}
            </Chip>

            <Modal open={open} onClose={() => setOpen(false)}>
                <ModalDialog layout="center" size="lg">
                    <Typography level="h4">Email Event History</Typography>
                    <Sheet variant="outlined" sx={{ mt: 2 }}>
                        <Table variant="soft">
                            <thead>
                                <tr>
                                    <th style={{ width: '50%' }}>Time</th>
                                    <th style={{ width: '50%', textAlign: "center" }}>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                {messageEvents.map((event, index) => {
                                    const eventStatus = event.event ?? event.status;
                                    const when = new Date(
                                        typeof event.timestamp === "number" && event.timestamp < 1e12
                                            ? event.timestamp * 1000
                                            : event.timestamp ?? event.last_event_time
                                    );
                                    const rowStatusColor = statusColors[eventStatus] || statusColors.default;
                                    const rowStatusIcon = statusIcons[eventStatus] || statusIcons.default;

                                    return (
                                        <tr key={index}>
                                            <td>
                                                {DateUtils.formatDate(when)}
                                                <Typography level="body-xs">
                                                    {DateUtils.formatTime(when)}
                                                </Typography>
                                            </td>
                                            <td style={{ textAlign: "center" }}>
                                                <Chip
                                                    color={rowStatusColor}
                                                    startDecorator={rowStatusIcon}
                                                    sx={{ px: 2, textTransform: "capitalize" }}
                                                >
                                                    {eventStatus}
                                                </Chip>
                                                {event.reason ? (
                                                    <Typography level="body-xs">{event.reason}</Typography>
                                                ) : null}
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </Table>
                    </Sheet>
                </ModalDialog>
            </Modal>
        </>
    );
};

EmailStatusChip.propTypes = {
    invitation: PropTypes.shape({
        messageEvents: PropTypes.arrayOf(
            PropTypes.shape({
                timestamp: PropTypes.string,
                last_event_time: PropTypes.string,
                event: PropTypes.string,
                status: PropTypes.string,
                reason: PropTypes.string,
                opens_count: PropTypes.number,
                clicks_count: PropTypes.number
            })
        ),
    }).isRequired,
};

export default EmailStatusChip;
