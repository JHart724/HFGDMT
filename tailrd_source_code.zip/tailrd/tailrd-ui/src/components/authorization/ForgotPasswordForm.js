import {useState} from "react";
import {Button, Input, Stack, Typography} from "@mui/joy";
import PropTypes from "prop-types";

const ForgotPasswordForm = ({ onSend, onSignIn }) => {
    const [email, setEmail] = useState('');

    const handleSend = () => {
        onSend(email);
    };

    const handleSignIn = () => {
        onSignIn();
    }

    const isEnabled = email.trim() !== '';

    return (
        <Stack
            direction="column"
            spacing={3}
            sx={{
                justifyContent: "flex-start",
                alignItems: "center",
            }}
        >
            <Typography level="h2" textAlign="center">
                Forgot Password
            </Typography>
            <Input
                variant="outlined"
                placeholder="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                sx={{ maxWidth: 360, width: '100%' }}
            />

            <Stack
                direction="column"
                spacing={0}
                sx={{
                    justifyContent: "flex-start",
                    alignItems: "center",
                }}
            >
                <Button
                    size="lg"
                    sx={{ px: 7 }}
                    disabled={!isEnabled}
                    onClick={handleSend}
                >
                    Send Reset Link
                </Button>

                <Button
                    variant="plain"
                    color="neutral"
                    size="sm"
                    sx={{ fontWeight: 400 }}
                    onClick={handleSignIn}
                >
                    Back to Sign In
                </Button>
            </Stack>
        </Stack>
    );
}

ForgotPasswordForm.propTypes = {
    onSend: PropTypes.func.isRequired,
    onSignIn: PropTypes.func.isRequired
};

export default ForgotPasswordForm;
