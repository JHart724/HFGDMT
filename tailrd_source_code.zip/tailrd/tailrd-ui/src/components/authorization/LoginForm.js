import { Button, Input, Stack, Typography } from "@mui/joy";
import { useState } from 'react';
import PropTypes from 'prop-types';

const LoginForm = ({ onSignIn, onForgotPassword }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleSignIn = () => {
        onSignIn(username, password);
    };

    const handleForgotPassword = () => {
        onForgotPassword();
    };

    const isSigninEnabled = username.trim() !== '' && password.trim() !== '';

    return (
        <Stack
            direction="column"
            spacing={3}
            sx={{
                justifyContent: "flex-start",
                alignItems: "center",
            }}
        >
            <Typography level="h2" textAlign="center">
                Welcome
            </Typography>
            <Input
                variant="outlined"
                placeholder="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                sx={{ maxWidth: 360, width: '100%' }}
            />
            <Input
                variant="outlined"
                type="password"
                placeholder="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                sx={{ maxWidth: 360, width: '100%' }}
            />

            <Stack
                direction="column"
                spacing={0}
                sx={{
                    justifyContent: "flex-start",
                    alignItems: "center",
                }}
            >
                <Button
                    variant="plain"
                    color="neutral"
                    size="sm"
                    sx={{ fontWeight: 400 }}
                    onClick={handleForgotPassword}
                >
                    Forgot Password?
                </Button>

                <Button
                    size="lg"
                    sx={{ px: 7 }}
                    disabled={!isSigninEnabled}
                    onClick={handleSignIn}
                >
                    Sign In
                </Button>
            </Stack>
        </Stack>
    );
};

LoginForm.propTypes = {
    onSignIn: PropTypes.func.isRequired,
    onForgotPassword: PropTypes.func.isRequired
};

export default LoginForm;
