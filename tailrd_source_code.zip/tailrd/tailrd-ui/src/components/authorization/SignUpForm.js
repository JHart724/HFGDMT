import { Stack, Typography, Input, Button, FormControl, FormHelperText } from "@mui/joy";
import { useState, useMemo } from 'react';
import PropTypes from 'prop-types';

const SignUpForm = ({ onSignUp, email, code }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    const passwordValidation = useMemo(() => {
        const checks = {
            length: password.length >= 8,
            lowercase: /[a-z]/.test(password),
            uppercase: /[A-Z]/.test(password),
            number: /[0-9]/.test(password),
            special: /[!@#$%^&*(),.?":{}|<>]/.test(password),
        };

        return {
            ...checks,
            isValid: Object.values(checks).every(Boolean)
        };
    }, [password]);

    const handleSignUp = () => {
        onSignUp({
            username,
            code,
            password
        });
    };

    const isSignUpEnabled =
        username.trim() !== '' &&
        passwordValidation.isValid &&
        password === confirmPassword;

    return (
        <Stack
            direction="column"
            spacing={3}
            sx={{
                justifyContent: "flex-start",
                alignItems: "center",
            }}
        >
            <Typography level="h2" textAlign="center">
                Sign Up
            </Typography>
            <Typography level="body-sm" color="neutral" textAlign="center">
                {email}
            </Typography>
            <Input
                variant="outlined"
                placeholder="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                sx={{ maxWidth: 360, width: '100%' }}
            />
            <FormControl sx={{ maxWidth: 360, width: '100%' }}>
                <Input
                    variant="outlined"
                    type="password"
                    placeholder="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    error={password !== '' && !passwordValidation.isValid}
                />
                {password !== '' && !passwordValidation.isValid && (
                    <FormHelperText>
                        <Stack direction="column" spacing={0.5} sx={{ mt: 1 }}>
                            <Typography level="body-sm">
                                Password must contain:
                            </Typography>
                            <Typography level="body-xs" color={passwordValidation.length ? 'success' : 'danger'}>
                                • At least 8 characters
                            </Typography>
                            <Typography level="body-xs" color={passwordValidation.lowercase ? 'success' : 'danger'}>
                                • One lowercase letter
                            </Typography>
                            <Typography level="body-xs" color={passwordValidation.uppercase ? 'success' : 'danger'}>
                                • One uppercase letter
                            </Typography>
                            <Typography level="body-xs" color={passwordValidation.number ? 'success' : 'danger'}>
                                • One number
                            </Typography>
                            <Typography level="body-xs" color={passwordValidation.special ? 'success' : 'danger'}>
                                • One special character
                            </Typography>
                        </Stack>
                    </FormHelperText>
                )}
            </FormControl>
            <Input
                variant="outlined"
                type="password"
                placeholder="confirm password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                error={confirmPassword !== '' && password !== confirmPassword}
                sx={{ maxWidth: 360, width: '100%' }}
            />

            <Button
                size="lg"
                sx={{ px: 7 }}
                disabled={!isSignUpEnabled}
                onClick={handleSignUp}
            >
                Sign Up
            </Button>
        </Stack>
    );
};

SignUpForm.propTypes = {
    onSignUp: PropTypes.func.isRequired,
    email: PropTypes.string.isRequired,
    code: PropTypes.string.isRequired,
};

export default SignUpForm;
