import BasicArray from 'domain/BasicArray';
import Patient from 'domain/Patient';

export default class PatientArray extends BasicArray {
    get myItemClass() { return Patient; }

    constructor(items = []) {
        super(items);
    }
}
