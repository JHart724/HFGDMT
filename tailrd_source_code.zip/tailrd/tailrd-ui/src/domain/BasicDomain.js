export default class BasicDomain extends global.Parse.Object {

    constructor(className, props = {}, defaults = {}) {
        super(className);

        // Retain attributes
        let attr = defaults;
        if (props.attributes) {
            attr = {...defaults, ...props.attributes}
        } else if (typeof yourVariable === 'object') {
            attr = {...defaults, ...props}
        }

        if(props.id) {
            super.set('id', props.id);
            attr['_localId'] = props._localId; // Used by LiveQuery to persist objects across calls
        }

        super.set(attr)
        this._initOriginalValues(props._originalValues ?? {});

        // Dynamically create getters and setters for each property in defaults
        Object.keys(defaults).forEach(key => {
            if (!this[key]) {
                Object.defineProperty(this, key, {
                    get: function() {
                        return this.get(key) ?? defaults[key];
                    },
                    set: function(value) {
                        this.set(key, value ?? defaults[key]);
                    },
                });
            }
        });
    }

    _initOriginalValues(incoming = {}) {
        this._originalValues = {...incoming}
    }

    _logOriginalValue(key, nextValue, prevValue) {
        if (this._originalValues[key] === undefined) {
            this._originalValues[key] = prevValue;
        } else if (this._originalValues[key] === nextValue) {
            delete this._originalValues[key];
        }
    }

    set(key, value, options) {
        if (typeof key === 'object') {
            Object.keys(key).forEach(k => {
                this._logOriginalValue(k, value, this.get(k));
            });
        } else {
            this._logOriginalValue(key, value, this.get(key));
        }
        return super.set(key, value, options);
    }

    reset() {
        super.set(this._originalValues);
        this._initOriginalValues();
        return this;
    }

    async save(...args) {
        this._initOriginalValues();
        return super.save(...args);
    }

    isDirty = () => Object.keys(this._originalValues).length > 0;

    dirtyKeys = () => Object.keys(this._originalValues);

    isSavable = () => false;
}
