import BasicArray from 'domain/BasicArray';
import Organization from 'domain/Organization';

export default class OrganizationArray extends BasicArray {
    get myItemClass() { return Organization; }

    constructor(items = []) {
        super(items);
    }
}
