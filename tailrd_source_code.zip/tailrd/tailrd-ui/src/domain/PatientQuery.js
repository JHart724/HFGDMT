import Patient from "./Patient";

const { Parse } = global;

/**
 * Example usage:
 * const query = new PatientQuery()
 *    .add(PatientQuery.FIELD_AGE, { min: 50, max: 70 })
 *    .add(PatientQuery.FIELD_HEART_FAILURE_CLASS, 2)
 *    .add(PatientQuery.FIELD_SEX, Patient.SEX_MALE)
 *    .sort(PatientQuery.FIELD_MRN, PatientQuery.SORT_DESC);
 *
 * console.log(query.getFilters()); // Output: { ageAtAdmission: { min: 50, max: 70 }, hfClass: 2, sex: "Male" }
 * console.log(query.getSorting()); // Output: { sortBy: "mrn", sortDirection: "desc" }
 */
export default class PatientQuery {

    static SORT_ASC = "asc";
    static SORT_DESC = "desc";
    static SORT_NONE = "none";

    // Constants for field names
    static FIELD_AGE = "ageAtAdmission";
    static FIELD_SEX = "sex";
    static FIELD_RACE = "race";
    static FIELD_MRN = "mrn";
    static FIELD_HEART_FAILURE_CLASS = "hfClass";
    static FIELD_BB = "bb";
    static FIELD_DISCHARGING_PHYSICIAN = "dischargingPhysician";
    static FIELD_PCP = "primaryCarePhysician";
    static FIELD_CARDIOLOGIST = "consultingCardiologist";
    static FIELD_ADMITTING_PHYSICIAN = "admittingPhysician";

    // Array of all fields
    static FIELDS = [
        PatientQuery.FIELD_AGE,
        PatientQuery.FIELD_SEX,
        PatientQuery.FIELD_RACE,
        PatientQuery.FIELD_MRN,
        PatientQuery.FIELD_HEART_FAILURE_CLASS,
        PatientQuery.FIELD_PCP,
        PatientQuery.FIELD_DISCHARGING_PHYSICIAN,
        PatientQuery.FIELD_CARDIOLOGIST,
        PatientQuery.FIELD_ADMITTING_PHYSICIAN,
    ];

    // Subset arrays for sortable and filterable fields
    static SORTABLE_FIELDS = [
        PatientQuery.FIELD_MRN,
        PatientQuery.FIELD_SEX,
        PatientQuery.FIELD_RACE,
        PatientQuery.FIELD_AGE,
        PatientQuery.FIELD_HEART_FAILURE_CLASS,
    ];

    static FILTERABLE_FIELDS = [
        PatientQuery.FIELD_AGE,
        PatientQuery.FIELD_SEX,
        PatientQuery.FIELD_RACE,
        PatientQuery.FIELD_HEART_FAILURE_CLASS,
        PatientQuery.FIELD_PCP,
        PatientQuery.FIELD_DISCHARGING_PHYSICIAN,
        PatientQuery.FIELD_CARDIOLOGIST,
        PatientQuery.FIELD_ADMITTING_PHYSICIAN,
    ];

    // Field type mapping
    static FIELD_TYPE = {
        [PatientQuery.FIELD_MRN]: "String",
        [PatientQuery.FIELD_DISCHARGING_PHYSICIAN]: "Provider",
        [PatientQuery.FIELD_PCP]: "Provider",
        [PatientQuery.FIELD_AGE]: "Number",
        [PatientQuery.FIELD_SEX]: Patient.SEXES,
        [PatientQuery.FIELD_RACE]: Patient.RACES,
        [PatientQuery.FIELD_HEART_FAILURE_CLASS]: [1, 2, 3, 4],
    };

    // Field labels mapping
    static FIELD_LABELS = {
        [PatientQuery.FIELD_AGE]: "Age",
        [PatientQuery.FIELD_SEX]: "Sex",
        [PatientQuery.FIELD_RACE]: "Race",
        [PatientQuery.FIELD_MRN]: "Medical Record Number (MRN)",
        [PatientQuery.FIELD_HEART_FAILURE_CLASS]: "Heart Failure Class",
        [PatientQuery.FIELD_DISCHARGING_PHYSICIAN]: "Discharging Physician",
        [PatientQuery.FIELD_PCP]: "Primary Care Physician (PCP)",
        [PatientQuery.FIELD_CARDIOLOGIST]: "Consulting Cardiologist",
        [PatientQuery.FIELD_ADMITTING_PHYSICIAN]: "Admitting Physician",
    };

    constructor(initialValues = {}) {
        this.filters = {};
        this.sortBy = PatientQuery.FIELD_MRN;
        this.sortDirection = PatientQuery.SORT_ASC;

        if (initialValues instanceof PatientQuery) {
            this.filters = { ...initialValues.filters };
            this.sortBy = initialValues.sortBy;
            this.sortDirection = initialValues.sortDirection;
        } else if (typeof initialValues === "object" && initialValues !== null) {
            if (initialValues.filters) {
                for (const [field, value] of Object.entries(initialValues.filters)) {
                    this.add(field, value);
                }
            }
            if (initialValues.sortBy) {
                this.setSort(initialValues.sortBy, initialValues.sortDirection || PatientQuery.SORT_ASC);
            }
        }
    }


    // Add a filter (field must be filterable)
    add(field, value) {
        if (!PatientQuery.FILTERABLE_FIELDS.includes(field)) {
            throw new Error(`Field "${field}" cannot be filtered.`);
        }

        if (PatientQuery.FIELD_TYPE[field] === "Number") {
            if (typeof value === "object" && (value.min !== undefined || value.max !== undefined)) {
                this.filters[field] = value;
            } else {
                throw new Error(`Field "${field}" must be filtered with an object containing 'min' and/or 'max'.`);
            }
        } else {
            this.filters[field] = value;
        }

        return this;
    }

    // Remove a filter
    remove(field) {
        delete this.filters[field];
        return this;
    }

    // Set sorting field and direction
    sort(field, direction = PatientQuery.SORT_ASC) {
        if (!PatientQuery.SORTABLE_FIELDS.includes(field)) {
            throw new Error(`Field "${field}" cannot be sorted.`);
        }
        if (![PatientQuery.SORT_DESC, PatientQuery.SORT_ASC].includes(direction)) {
            throw new Error('Sort direction must be PatientQuery.SORT_DESC or PatientQuery.SORT_ASC.');
        }
        this.sortBy = field;
        this.sortDirection = direction;
        return this;
    }

    // Clear sorting
    clearSort() {
        this.sortBy = null;
        this.sortDirection = PatientQuery.SORT_NONE;
    }

    // Get the applied filters
    getFilters() {
        return { ...this.filters };
    }

    // Get sorting settings
    getSorting() {
        return {
            sortBy: this.sortBy,
            sortDirection: this.sortDirection,
        };
    }

    /**
     * Applies the filters to the Parse query.
     *
     * @param {Parse.Query} query - The query to apply filters to.
     * @returns {Parse.Query} - The modified Parse query.
     */
    applyFilters(query) {
        for (const [field, value] of Object.entries(this.filters)) {
            const fieldType = PatientQuery.FIELD_TYPE[field];

            if (fieldType === "Number") {
                if (value.min !== undefined) query.greaterThanOrEqualTo(field, value.min);
                if (value.max !== undefined) query.lessThanOrEqualTo(field, value.max);
            } else if (fieldType === "Provider") {
                const providerQuery = new Parse.Query(fieldType);

                if (Array.isArray(value)) {
                    providerQuery.containedIn("name", value);
                } else if (typeof value === "string") {
                    if (value.includes("%")) {
                        providerQuery.matches("name", value.replace(/%/g, ".*"), "i");
                    } else {
                        providerQuery.equalTo("name", value);
                    }
                }

                query.matchesQuery(field, providerQuery);
            } else if (Array.isArray(value)) {
                query.containedIn(field, value);
            } else if (typeof value === "string" && value.includes("%")) {
                query.matches(field, value.replace(/%/g, ".*"), "i");
            } else {
                query.equalTo(field, value);
            }
        }
        return query;
    }

    /**
     * Applies the sorting to the parse query.
     *
     * @param Parse.ParseQeury query The query to apply sorting to.
     * @returns Parse.ParseQeury
     */
    applySort(query) {
        let mySortBy = this.sortBy ?? PatientQuery.FIELD_MRN;
        let mySortDirection = this.sortDirection ?? PatientQuery.SORT_ASC;

        if (!PatientQuery.SORTABLE_FIELDS.includes(mySortBy)) {
            mySortBy = PatientQuery.FIELD_MRN
        }

        if (mySortDirection === PatientQuery.SORT_DESC) {
            return query.descending(mySortBy)
        }

        return query.ascending(mySortBy)
    }

    /**
     * Applies the query settings to the parse query.
     *
     * @param Parse.ParseQeury query The query to apply settings to.
     * @returns Parse.ParseQeury
     */
    apply(query) {
        return this.applyFilters(this.applySort(query));
    }
}
