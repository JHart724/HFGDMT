import BasicDomain from './BasicDomain';

export default class RegistrationCode extends BasicDomain {
    static STATUS_PENDING = 'PENDING';

    static STATUS_CANCELED = 'CANCELED';

    static STATUS_RESENT = 'RESENT';

    static STATUS_USED = 'USED';

    static STATUSES = [
        RegistrationCode.STATUS_PENDING,
        RegistrationCode.STATUS_CANCELED,
        RegistrationCode.STATUS_RESENT,
        RegistrationCode.STATUS_USED,
    ]

    static STATUS_LABELS = {
        [RegistrationCode.STATUS_PENDING]: 'Pending',
        [RegistrationCode.STATUS_CANCELED]: 'Canceled',
        [RegistrationCode.STATUS_RESENT]: 'Resent',
        [RegistrationCode.STATUS_USED]: 'Used',
    }

    static DEFAULTS = {
        email: null,
        sent: null,
        expires: null,
        messageId: null,
        messageEvents: [],
        status: RegistrationCode.STATUS_PENDING,
    }

    static FIELDS = Object.keys(RegistrationCode.DEFAULTS);

    constructor(props) {
        super('RegistrationCode', props, RegistrationCode.DEFAULTS);
    }

    toString = () => (this.isNew() ? 'New Registration Code' : this.name);

    isSavable = () => (
        this.name != null
        && this.name.trim() !== ''
    );
}

global.Parse.Object.registerSubclass('RegistrationCode', RegistrationCode);
