import BasicDomain from './BasicDomain';

export default class Organization extends BasicDomain {
    static STATUS_ACTIVE = 'ACTIVE';

    static STATUS_INACTIVE = 'INACTIVE';

    static STATUSES = [
        Organization.STATUS_ACTIVE,
        Organization.STATUS_INACTIVE,
    ]

    static STATUS_LABELS = {
        [Organization.STATUS_ACTIVE]: 'Active',
        [Organization.STATUS_INACTIVE]: 'Inactive',
    }

    static DEFAULTS = {
        name: '',
        status: Organization.STATUS_ACTIVE,
    }

    static FIELDS = Object.keys(Organization.DEFAULTS);

    constructor(props) {
        super('Organization', props, Organization.DEFAULTS);
    }

    toString = () => (this.isNew() ? 'New Organization' : this.name);

    isSavable = () => (
        this.name != null
        && this.name.trim() !== ''
    );
}

global.Parse.Object.registerSubclass('Organization', Organization);
