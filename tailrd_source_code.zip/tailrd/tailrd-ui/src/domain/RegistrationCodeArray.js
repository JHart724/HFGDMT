import BasicArray from 'domain/BasicArray';
import RegistrationCode from 'domain/RegistrationCode';

export default class RegistrationCodeArray extends BasicArray {
    get myItemClass() { return RegistrationCode; }

    constructor(items = []) {
        super(items);
    }

    /**
     * Comparator function to sort by `sent` date in descending order (newest first).
     * @param {RegistrationCode} a - First registration code.
     * @param {RegistrationCode} b - Second registration code.
     * @returns {number} - Negative if `b` is more recent, positive if `a` is more recent, 0 if equal.
     */
    comparator = (a, b) => new Date(b.sent) - new Date(a.sent);
}
