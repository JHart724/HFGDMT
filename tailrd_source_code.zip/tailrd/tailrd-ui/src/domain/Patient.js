import BasicDomain from './BasicDomain';

export default class Patient extends BasicDomain {

    static SEX_MALE = "Male";
    static SEX_FEMALE = "Female";
    static SEX_OTHER = "Other";

    static SEXES = [
        Patient.SEX_MALE,
        Patient.SEX_FEMALE,
        Patient.SEX_OTHER,
    ];

    static SEX_LABELS = {
        [Patient.SEX_MALE]: "Male",
        [Patient.SEX_FEMALE]: "Female",
        [Patient.SEX_OTHER]: "Other",
    };

    static RACE_OTHER = "Other";
    static RACE_ASIAN = "Asian";
    static RACE_BLACK = "Black";
    static RACE_HISPANIC = "Hispanic";
    static RACE_WHITE = "White";

    static RACES = [
        Patient.RACE_OTHER,
        Patient.RACE_ASIAN,
        Patient.RACE_BLACK,
        Patient.RACE_HISPANIC,
        Patient.RACE_WHITE,
    ];

    static RACE_LABELS = {
        [Patient.RACE_OTHER]: "Other",
        [Patient.RACE_ASIAN]: "Asian",
        [Patient.RACE_BLACK]: "Black",
        [Patient.RACE_HISPANIC]: "Hispanic",
        [Patient.RACE_WHITE]: "White",
    };

    static HF_CLASS_LABELS = {
        [1]: "I",
        [2]: "II",
        [3]: "III",
        [4]: "IV",
    };

    static DEFAULTS = {
        organization: null,
        mrn: "",
        ageAtAdmission: null,
        hfClass: 0,
        sex: Patient.SEX_OTHER,
        race: Patient.RACE_OTHER,
        insuranceType: null,
        zipCode: null,
        admissionDate: null,
        dischargeDate: null,
        dischargeDisposition: null,
        admittingService: null,
        scheduledFollowUp: null,
        followUpType: null,
        followUpTimeframe: null,
        admittingPhysician: null,
        dischargingPhysician: null,
        consultingCardiologist: null,
        primaryCarePhysician: null,
        createdAt: null,
        updatedAt: null,
    }

    static FIELDS_OBJECTS = ["dischargingPhysician", "consultingCardiologist", "primaryCarePhysician", "admittingPhysician"];

    static FIELDS = [
        ...Object.keys(Patient.DEFAULTS),
        ...Patient.FIELDS_OBJECTS.map(field => `${field}.name`)
    ];

    constructor(props) {
        super('Patient', props, Patient.DEFAULTS);
    }

    get hfClassLabel() {
        return Patient.HF_CLASS_LABELS[this.hfClass] || "-";
    }

    get dischargingPhysicianName() {
        return this.dischargingPhysician ? `Dr. ${this.dischargingPhysician?.get('name')}` : null;
    }

    get primaryCarePhysicianName() {
        return this.primaryCarePhysician ? `Dr. ${this.primaryCarePhysician?.get('name')}` : null;
    }

    get consultingCardiologistName() {
        return this.consultingCardiologist ? `Dr. ${this.consultingCardiologist?.get('name')}` : null;
    }

    get admittingPhysicianName() {
        return this.admittingPhysician ? `Dr. ${this.admittingPhysician?.get('name')}` : null;
    }

    toString = () => (this.isNew() ? 'New Patient' : this.mrn);

    isSavable = () => false;
}

global.Parse.Object.registerSubclass('Patient', Patient);
