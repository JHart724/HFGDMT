/**
 * Common utility functions for date formatting and other reusable logic.
 *
 * For more date/time formatting options without using a library, refer to:
 * https://dockyard.com/blog/2020/02/14/you-probably-don-t-need-moment-js-anymore
 */

/**
 * Time unit constants for use with `timeDiff`, `timeTo`, and `timeFrom`.
 */
const TIME_GRAINS = {
    SECONDS: "seconds",
    MINUTES: "minutes",
    HOURS: "hours",
    DAYS: "days",
    WEEKS: "weeks",
};

/**
 * Precomputed time unit conversions (in milliseconds).
 */
const conversion = {
    [TIME_GRAINS.SECONDS]: 1_000,           // 1 second = 1,000 ms
    [TIME_GRAINS.MINUTES]: 60_000,          // 1 minute = 60,000 ms
    [TIME_GRAINS.HOURS]: 3_600_000,         // 1 hour = 3,600,000 ms
    [TIME_GRAINS.DAYS]: 86_400_000,         // 1 day = 86,400,000 ms
    [TIME_GRAINS.WEEKS]: 604_800_000,       // 1 week = 604,800,000 ms
};

/**
 * Returns the current date;
 * @returns {Date}
 */
const now = () => new Date();

/**
 * Returns the ordinal suffix for a given day.
 * @param {number} day - The day of the month.
 * @returns {string} The ordinal suffix (e.g., "st", "nd", "rd", "th").
 */
const getOrdinalSuffix = (day) => {
    if (day > 3 && day < 21) return "th"; // Covers 4th - 20th
    switch (day % 10) {
        case 1: return "st";
        case 2: return "nd";
        case 3: return "rd";
        default: return "th";
    }
};

/**
 * Formats a given date into a readable format: "Feb 29th, 2025".
 * @param {Date | string | number} date - The date object or timestamp to format.
 * @returns {string} Formatted date as "MMM Do, YYYY" (e.g., "Feb 29th, 2025").
 */
const formatDate = (date) => {
    if (!date) return '';

    const d = new Date(date);
    const day = d.getDate();
    const suffix = getOrdinalSuffix(day);

    return new Intl.DateTimeFormat('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
    }).format(d).replace(/\d+/, `${day}${suffix}`);
};

/**
 * Formats a given date into a readable time format: "10:30 AM".
 * @param {Date | string | number} date - The date object or timestamp to format.
 * @returns {string} Formatted time as "HH:MM AM/PM".
 */
const formatTime = (date) => {
    if (!date) return '';

    return new Date(date).toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
    });
};

/**
 * Formats a given date into a readable format with time: "Feb 29th, 2025, 10:30 AM".
 * @param {Date | string | number} date - The date object or timestamp to format.
 * @returns {string} Formatted date and time as "MMM Do, YYYY, HH:MM AM/PM".
 */
const formatDateTime = (date) => {
    if (!date) return '';

    const d = new Date(date);
    const formattedDate = formatDate(d);

    const formattedTime = d.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
    });

    return `${formattedDate} ${formattedTime}`;
};

/**
 * Calculates the difference between two dates in the specified unit (grain).
 * @param {Date | string | number} date1 - The first date.
 * @param {Date | string | number} date2 - The second date (defaults to `new Date()`).
 * @param {string} grain - The unit of time difference (use `TIME_GRAINS` constants).
 * @param {boolean} [absolute=true] - Whether to return the absolute difference (default: true).
 * @returns {number} The difference in the specified unit.
 */
const timeDiff = (date1, date2 = new Date(), grain = TIME_GRAINS.DAYS, absolute = false) => {
    const d1 = new Date(date1).getTime();
    const d2 = new Date(date2).getTime();
    let diffMs = d1 - d2;

    if (absolute) {
        diffMs = Math.abs(diffMs);
    }

    if (!conversion[grain]) {
        throw new Error(`Invalid grain: "${grain}". Use one of ${Object.values(TIME_GRAINS).join(", ")}`);
    }

    return diffMs / conversion[grain];
};

/**
 * Returns a human-readable "time until" a given date (e.g., "in 5 days").
 * @param {Date | string | number} targetDate - The target date.
 * @param {Date | string | number} [fromDate=new Date()] - The reference date.
 * @returns {string} A human-readable string like "in 5 days" or "in 3 hours".
 */
const timeTo = (targetDate, fromDate = new Date()) => {
    for (const grain of [TIME_GRAINS.WEEKS, TIME_GRAINS.DAYS, TIME_GRAINS.HOURS, TIME_GRAINS.MINUTES, TIME_GRAINS.SECONDS]) {
        const diff = timeDiff(targetDate, fromDate, grain, false);
        if (Math.abs(diff) >= 1) {
            return `in ${Math.abs(Math.round(diff))} ${grain}`;
        }
    }
    return "just now";
};

/**
 * Returns a human-readable "time since" a given date (e.g., "5 days ago").
 * @param {Date | string | number} pastDate - The past date.
 * @param {Date | string | number} [toDate=new Date()] - The reference date.
 * @returns {string} A human-readable string like "5 days ago" or "3 hours ago".
 */
const timeFrom = (pastDate, toDate = new Date()) => {
    for (const grain of [TIME_GRAINS.WEEKS, TIME_GRAINS.DAYS, TIME_GRAINS.HOURS, TIME_GRAINS.MINUTES, TIME_GRAINS.SECONDS]) {
        const diff = timeDiff(pastDate, toDate, grain, false);
        if (Math.abs(diff) >= 1) {
            return `${Math.abs(Math.round(diff))} ${grain} ago`;
        }
    }
    return "just now";
};

export default {
    now,
    formatDate,
    formatTime,
    formatDateTime,
    timeDiff,
    timeTo,
    timeFrom,
    ...TIME_GRAINS,
};
