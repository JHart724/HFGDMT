import { useSelector } from 'react-redux';

/**
 * Authorization roles constants.
 */
export const AUTH_ROLES = {
    USER: 'USER',
    ADMIN: 'ADMIN',
    SYSTEM_ADMIN: 'SYS_ADMIN',
};

/**
 * Custom hook for authorization checks.
 *
 * This hook retrieves the authentication state from the Redux store and provides
 * helper methods to determine if the user has specific roles.
 *
 * There are two usage patterns:
 *
 * 1. To access the full auth object with helper methods:
 *
 *    const { me, isAuthorized, hasRole, hasAnyRole, hasAllRoles } = useAuth();
 *
 * 2. To check for specific roles using a shorthand:
 *
 *    const [isAdmin, isSysAdmin] = useAuth([AUTH_ROLES.ADMIN, AUTH_ROLES.SYSTEM_ADMIN]);
 *
 * In the second usage, the hook returns an array of booleans corresponding to each
 * role in the provided array.
 *
 * @param {string[]} [requiredRoles] - Optional array of roles to check against the user's authorizations.
 * @returns {Object|boolean[]} - If `requiredRoles` is provided, returns an array of booleans indicating
 *                              whether the user has each role. Otherwise, returns an object containing:
 *                                - me: the current user object,
 *                                - authorizations: an array of the user's roles,
 *                                - isAuthorized: a boolean flag,
 *                                - hasRole: function to check a single role,
 *                                - hasAnyRole: function to check if the user has any of a set of roles,
 *                                - hasAllRoles: function to check if the user has all of a set of roles.
 */
const useAuth = (requiredRoles) => {
    const { me, authorizations, isAuthorized } = useSelector((state) => state.auth);

    /**
     * Checks if the user has the specified role.
     *
     * @param {string} role - The role to check.
     * @returns {boolean} True if the role is present in the user's authorizations.
     */
    const hasRole = (role) => authorizations.includes(role);

    const authHelpers = {
        me,
        authorizations,
        isAuthorized,
        hasRole,
        hasAnyRole: (roles) => roles.some((role) => hasRole(role)),
        hasAllRoles: (roles) => roles.every((role) => hasRole(role)),
    };

    if (Array.isArray(requiredRoles)) {
        return requiredRoles.map((role) => hasRole(role));
    }

    return authHelpers;
};

export default useAuth;
