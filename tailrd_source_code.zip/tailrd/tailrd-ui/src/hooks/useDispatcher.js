import { useDispatch } from 'react-redux';
import noticeActions from 'actions/noticeActions';
import Notice from 'domain/Notice';

/**
 * Custom hook that returns a dispatcher function which handles Redux actions,
 * dispatching success or error notifications based on the outcome.
 *
 * Usage:
 *
 * const dispatcher = useDispatcher();
 *
 * // Dispatch an action with custom messages:
 * dispatcher(organizationActions.save(newObj), "Organization saved", "Failed to save organization")
 *   .then(response => { ... });
 *
 * @returns {Function} A dispatcher function that takes an action (promise),
 * a success message, and an error message, and returns a promise.
 */
const useDispatcher = () => {
    const dispatch = useDispatch();

    const dispatcher = (action, successMessage = 'Success', errorMessage = 'Error') => {
        return dispatch(action)
            .then((response) => {
                const successMsg =
                    typeof successMessage === 'string'
                        ? { title: successMessage, type: Notice.TYPE_SUCCESS }
                        : { type: Notice.TYPE_SUCCESS, ...successMessage };
                dispatch(noticeActions.add(new Notice(successMsg)));
                return response;
            })
            .catch((error) => {
                const errorMsg =
                    typeof errorMessage === 'string'
                        ? { title: errorMessage, details: error.details, type: Notice.TYPE_ERROR }
                        : { type: Notice.TYPE_ERROR, details: error.details, ...errorMessage };
                dispatch(noticeActions.add(new Notice(errorMsg)));
                return error;
            });
    };

    return dispatcher;
};

export default useDispatcher;
