import {Notice} from "domain";

const add = (note) => {
    return {
        type: 'ADD_NOTICE',
        payload: Promise.resolve(new Notice(note)),
    };
}

const update = (note) => {
    return {
        type: 'UPDATE_NOTICE',
        payload: Promise.resolve(new Notice(note)),
    };
}

const remove = (note) => {
    return {
        type: 'REMOVE_NOTICE',
        payload: Promise.resolve(new Notice(note)),
    };
}

const clear = () => {
    return {
        type: 'CLEAR_NOTICE',
        payload: Promise.resolve(),
    };
}

export default {
    add,
    update,
    remove,
    clear,
};
