import {RegistrationCode} from "domain";

const { Parse } = global;

const save = (regCode) => ({
    type: "SAVE_REGISTRATION",
    payload: regCode.save(),
});

const list = (id) => ({
    type: "LIST_REGISTRATION",
    payload: new Parse.Query(RegistrationCode)
        .select(RegistrationCode.FIELDS)
        .equalTo('organization', id)
        .equalTo('status', RegistrationCode.STATUS_PENDING)
        .findAll(),
});

const send = (email, id) => ({
    type: "SEND_REGISTRATION",
    meta: { email, id },
    payload: Parse.Cloud.run('send', { email, id }),
});

export default {
    save,
    list,
    send,
};
