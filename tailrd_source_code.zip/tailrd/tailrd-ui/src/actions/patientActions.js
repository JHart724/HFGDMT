import { Patient, PatientQuery } from 'domain';

const { Parse } = global;

const get = (id) => ({
    type: "GET_PATIENT",
    meta: { id },
    payload: new Parse.Query(Patient)
        .select(Patient.FIELDS)
        .include(Patient.FIELDS_OBJECTS)
        .equalTo("organization", Parse.User.current()?.get("organization"))
        .get(id),
});

const set = (pt) => ({
    type: "SET_PATIENT",
    meta: { pt },
    payload: Promise.resolve(pt),
});

const list = (settings = new PatientQuery(), offset = 0, limit = 20) => ({
    type: "LIST_PATIENT",
    meta: { settings, offset, limit },
    payload: settings.apply(new Parse.Query(Patient))
        .select(Patient.FIELDS)
        .include(Patient.FIELDS_OBJECTS)
        .equalTo("organization", Parse.User.current()?.get("organization"))
        .skip(offset)
        .limit(limit)
        .find(),
});

const save = (pt) => ({
    type: "SAVE_PATIENT",
    meta: { pt },
    payload: pt.save(),
});

const clear = () => ({
    type: "CLEAR_PATIENT",
    meta: {},
    payload: Promise.resolve(),
});

const checkStatus = (id) => {
    return {
        type: `CHECK_PATIENT_STATUS`,
        meta: { id },
        payload: Parse.Cloud.run('checkPtStatus', { id }),
    };
};

export default {
    list,
    save,
    get,
    set,
    clear,
    checkStatus,
};
