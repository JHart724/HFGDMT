const Parse = global.Parse;

/**
 * Attempts a user login.
 *
 * @param {string} username - The username.
 * @param {string} password - The password.
 */
const login = (username, password) => {
    return {
        type: `LOGIN`,
        payload: Parse.User.logIn(username, password),
    };
};

/**
 * Logout the current user.
 */
const logout = () => {
    return {
        type: `LOGOUT`,
        payload: Parse.User.logOut(),
    };
};

/**
 * Restore the current user's details, if authenticated.
 */
const restore = () => {
    return {
        type: `RESTORE`,
        payload: Promise.resolve(Parse.User.current()),
    };
};

const validateCode = (code) => {
    return {
        type: `VALIDATE_CODE`,
        payload: Parse.Cloud.run('validateCode', { code }),
    };
}

/**
 * Logout the current user.
 */
const register = ({ username, password, registrationCode }) => {
    return {
        type: `REGISTER`,
        meta: { username, password, registrationCode },
        payload: Parse.Cloud.run('register', { username, password, registrationCode }),
    };
};

/**
 * Check the current user's authorizations.
 */
const authorize = () => {
    return {
        type: `AUTHORIZE`,
        payload: Parse.Cloud.run('authorize'),
    };
};

/**
 * Logout the current user.
 */
const requestPasswordReset = (email) => {
    return {
        type: `PASSWORD_RESET`,
        meta: { email },
        payload: Parse.User.requestPasswordReset(email),
    };
};

export default {
    login,
    logout,
    restore,
    register,
    authorize,
    requestPasswordReset,
    validateCode,
};
