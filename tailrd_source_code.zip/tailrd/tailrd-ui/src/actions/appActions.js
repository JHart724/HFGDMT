const { Parse } = global;

const dashboard = () => {
    return {
        type: `DASHBOARD`,
        payload: Parse.Cloud.run('dashboard'),
    };
};

export default {
    dashboard
};
