import { Organization } from 'domain';

const { Parse } = global;

const get = (id) => ({
    type: "GET_ORGANIZATION",
    meta: { id },
    payload: new Parse.Query(Organization)
        .select(Organization.FIELDS)
        .get(id),
});

const set = (org) => ({
    type: "SET_ORGANIZATION",
    meta: { org },
    payload: Promise.resolve(org),
});

const list = ({ status } = {}) => ({
    type: "LIST_ORGANIZATION",
    payload: new Parse.Query(Organization)
        .select(Organization.FIELDS)
        .equalTo('status', status ?? Organization.STATUS_ACTIVE)
        .findAll(),
});

const save = (organization) => ({
    type: "SAVE_ORGANIZATION",
    payload: organization.save(),
});

const listUsers = (id, isActive = true) => {
    return {
        type: `LIST_ORGANIZATION_USERS`,
        meta: { id, isActive },
        payload: Parse.Cloud.run('listUsers', { id, isActive }),
    };
};

const changeUserStatus = (id, isActive = true) => {
    return {
        type: `CHANGE_ORGANIZATION_USER`,
        meta: { id, isActive },
        payload: Parse.Cloud.run('changeUserStatus', { id, isActive }),
    };
};

export default {
    list,
    save,
    get,
    set,
    listUsers,
    changeUserStatus,
};
