import { createRoot } from 'react-dom/client';
import {BrowserRouter, Route, Routes} from 'react-router-dom';
import { Provider } from 'react-redux';
import CssBaseline from '@mui/joy/CssBaseline';
import { CssVarsProvider } from '@mui/joy/styles';

import {initialize} from 'utils/ParseUtils';
import createAppStore from './store';
import theme from './theme';

import Authorize from 'components/ui/Authorize';
import Layout from 'components/ui/Layout';
import NotFoundView from 'views/NotFoundView';
import SignUpView from "views/unauthorized/SignUpView";
import AdminView from "views/admin/AdminView";
import OrgDetailsView from "views/admin/OrgDetailsView";
import DashboardView from "views/dashboard/DashboardView";
import PatientList from "views/patient/PatientList";
import PatientDetails from "views/patient/PatientDetails";

import './global.css';

initialize();
const store = createAppStore();
const root = createRoot(document.getElementById('root'));

root.render(
    <Provider store={store}>
        <CssVarsProvider theme={theme} defaultMode="light">
            <CssBaseline />
            <BrowserRouter>
                <Routes>
                    <Route element={<Layout />}>
                        <Route path="/signup" element={<SignUpView />} />
                        <Route element={<Authorize />}>
                            <Route exact path="/" element={<DashboardView />} />
                            <Route exact path="/admin" element={<AdminView />} />
                            <Route exact path="/admin/:id" element={<OrgDetailsView />} />
                            <Route exact path="/patient" element={<PatientList />} />
                            <Route exact path="/patient/:id" element={<PatientDetails />} />
                        </Route>
                        <Route path="*" element={<NotFoundView />} />
                    </Route>
                </Routes>
            </BrowserRouter>
        </CssVarsProvider>
    </Provider>
);
