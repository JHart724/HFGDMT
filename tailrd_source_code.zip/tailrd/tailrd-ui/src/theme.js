import { extendTheme } from '@mui/joy/styles';

const theme = extendTheme({
    fontFamily: {
        body: 'Inter, sans-serif',
        display: 'Montserrat, sans-serif',
    },
    typography: {
        "h1": {
            fontFamily: 'Montserrat, sans-serif',
            fontSize: '48px',
            fontWeight: 600,
            lineHeight: 1.3,
            filter: 'drop-shadow(0 4px 4px rgba(24, 34, 44, 0.40))',
        },
        "h2": {
            fontFamily: 'Montserrat, sans-serif',
            fontSize: '32px',
            fontWeight: 600,
            lineHeight: 1.3,
            filter: 'drop-shadow(0 4px 4px rgba(24, 34, 44, 0.40))',
        },
        "h3": {
            fontFamily: 'Montserrat, sans-serif',
            fontSize: '24px',
            fontWeight: 600,
            lineHeight: 1.3,
            filter: 'drop-shadow(0 4px 4px rgba(24, 34, 44, 0.40))',
        },
        "h4": {
            fontFamily: 'Montserrat, sans-serif',
            fontSize: '20px',
            fontWeight: 600,
            lineHeight: 1.3,
            filter: 'drop-shadow(0 4px 4px rgba(24, 34, 44, 0.40))',
        },
        "title-lg": {
            fontFamily: 'Montserrat, sans-serif',
            fontSize: '24px',
            fontWeight: 500,
            lineHeight: 1.4,
        },
        "title-md": {
            fontFamily: 'Montserrat, sans-serif',
            fontSize: '20px',
            fontWeight: 500,
            lineHeight: 1.4,
        },
        "title-sm": {
            fontFamily: 'Montserrat, sans-serif',
            fontSize: '16px',
            fontWeight: 500,
            lineHeight: 1.4,
        },
        "body-lg": {
            fontFamily: 'Inter, sans-serif',
            fontSize: '24px',
            fontWeight: 400,
            lineHeight: 1.5,
        },
        "body-md": {
            fontFamily: 'Inter, sans-serif',
            fontSize: '20px',
            fontWeight: 400,
            lineHeight: 1.5,
        },
        "body-sm": {
            fontFamily: 'Inter, sans-serif',
            fontSize: '16px',
            fontWeight: 400,
            lineHeight: 1.5,
        },
        "body-xs": {
            fontFamily: 'Inter, sans-serif',
            fontSize: '14px',
            fontWeight: 400,
            lineHeight: 1.5,
        }
    },
    components: {
        JoyRoot: {
            styleOverrides: {
                root: {
                    fontFamily: 'Inter, sans-serif',
                }
            }
        },
        JoyModalDialog: {
            defaultProps: {
                sx: {
                    width: { xs: '90%', sm: '450px', md: '550px' },
                    maxWidth: '600px'
                }
            }
        },
        JoyTable: {
            styleOverrides: {
                root: {
                    "& td[data-clamp]": {
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        maxWidth: 0,
                    },
                },
            },
        },
    },
    colorSchemes: {
        light: {
            palette: {
                primary: {
                    50: '#e7f3fa',
                    100: '#b8dcf1',
                    200: '#89C6E9', // Lighter primary
                    300: '#66A4CF',
                    400: '#4481B4',
                    500: '#215F9A', // Main primary color
                    600: '#1B5787',
                    700: '#165075',
                    800: '#104862', // Darker primary
                    900: '#0B3244',
                },
                danger: {
                    50: '#FAE7E7',
                    100: '#f5d0cf',
                    200: '#EBA2A0',
                    300: '#E27371',
                    400: '#D84542',
                    500: '#CE1613', // Main danger color
                    600: '#B4120E',
                    700: '#990F09',
                    800: '#7F0B04', // Darker danger
                    900: '#580702',
                },
                success: {
                    50: '#E9F8ED',
                    100: '#CDEDD7',
                    200: '#7CCD99',  // Given base color
                    300: '#5EB87F',
                    400: '#3FA265',
                    500: '#1F8C4B',
                    600: '#18703B',
                    700: '#12542A',
                    800: '#0C381A',
                    900: '#071C0D',
                },
                warning: {
                    50: '#FFF7F0',
                    100: '#FDE6CD',
                    200: '#F4B673',  // Given base color
                    300: '#E79C4D',
                    400: '#D88329',
                    500: '#C86A06',
                    600: '#A35505',
                    700: '#7F4004',
                    800: '#5B2B02',
                    900: '#371701',
                },
                neutral: {
                    50: '#F7F7F7',
                    100: '#EFEFEF',
                    200: '#D7D7D7',
                    300: '#BFBFBF',
                    400: '#8C8C8C', // main
                    500: '#595959',
                    600: '#404040',
                    700: '#262626',
                    800: '#1A1A1A',
                    900: '#0D0D0D',
                },
                chart: ['#215F9A', '#CE1613', '#104862', '#7F0B04', '#89C6E9'],
            }
        }
    }
});

export default theme;
