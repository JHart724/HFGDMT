const { merge } = require('webpack-merge');
const common = require('./webpack.common.js');

module.exports = merge(common, {
    mode: 'development',
    devtool: 'source-map', // Change to "eval" for fast builds, or "source-map" for accuracy
    devServer: {
        port: 8080,
        open: true,
        static: __dirname,
        devMiddleware: { stats: 'errors-only' },
        historyApiFallback: true,
    },
    externals: {
        Config: JSON.stringify({
            appUrl: 'https://app.tailrd-heart.com',
            apiUrl: 'https://api.tailrd-heart.com/api',
            wsUrl: 'ws://api.tailrd-heart.com/api',
            apiKey: 'JS.Wo8vePr6n0',
            apiId: 'Nn73TRvAStAl4zndujB5mf05vh7tveF3'
        }),
    },
});
