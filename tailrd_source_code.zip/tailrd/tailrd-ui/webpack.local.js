const { merge } = require('webpack-merge');
const common = require('./webpack.common.js');

module.exports = merge(common, {
    mode: 'development',
    devtool: 'source-map', // Change to "eval" for fast builds, or "source-map" for accuracy
    devServer: {
        port: 8080,
        open: true,
        static: __dirname,
        devMiddleware: { stats: 'errors-only' },
        historyApiFallback: true,
    },
    externals: {
        Config: JSON.stringify({
            appUrl: 'http://localhost:8080',
            apiUrl: 'http://localhost:1337/api',
            wsUrl: 'ws://localhost:1337/api',
            apiKey: 'myJSKey',
            apiId: 'myAppId'
        }),
    },
});
