const path = require('path');
const packageJson = require('./package.json');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');

module.exports = {
    entry: './src/index.js',
    target: 'web',
    mode: process.env.NODE_ENV ?? 'development',
    optimization: {
        splitChunks: {
            cacheGroups: {
                vendor: {
                    test: /[\\/]node_modules[\\/]/,
                    name: 'vendors',
                    chunks: 'all',
                    minSize: 60000,
                    maxSize: 240000,
                },
                domain: {
                    test: /domain/,
                    name: 'domain',
                    chunks: 'all',
                    minSize: 60000,
                    maxSize: 240000,
                    enforce: true,
                },
                img: {
                    test: /\.(webp|png|jpg|jpeg|gif|svg)$/,
                    name: 'img',
                    chunks: 'all',
                    minSize: 60000,
                    maxSize: 240000,
                    enforce: true,
                },
                main: {
                    name: 'main',
                    chunks: 'all',
                    minSize: 60000,
                    maxSize: 240000,
                    enforce: true,
                },
            },
        },
    },
    output: {
        path: path.resolve(__dirname, 'dist'),
        filename: `bundle-[name].[contenthash].${packageJson.version}.js`,
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                loader: 'babel-loader',
            },
            {
                test: /\.css$/,
                use: ['style-loader', 'css-loader'],
            },
            {
                test: /\.(png|jpg|jpeg|gif|svg|pdf)$/,
                use: [{ loader: 'url-loader', options: { limit: 100000 } }],
            },
        ],
    },
    resolve: {
        extensions: ['.js', '.jsx', '.json'],
        alias: {
            actions: path.resolve(__dirname, 'src/actions'),
            components: path.resolve(__dirname, 'src/components'),
            domain: path.resolve(__dirname, 'src/domain'),
            hooks: path.resolve(__dirname, 'src/hooks'),
            utils: path.resolve(__dirname, 'src/utils'),
            views: path.resolve(__dirname, 'src/views')
        }
    },
    plugins: [
        new CleanWebpackPlugin(),
        new HtmlWebpackPlugin({
            template: './src/index.html'
        }),
        new CopyWebpackPlugin({
            patterns: [
                { from: 'src/img', to: 'img' },
            ],
        }),
    ],
};
