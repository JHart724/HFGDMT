import { fixupConfigRules, fixupPluginRules } from "@eslint/compat";
import react from "eslint-plugin-react";
import reactHooks from "eslint-plugin-react-hooks";
import jsxA11Y from "eslint-plugin-jsx-a11y";
import _import from "eslint-plugin-import";
import unusedImports from "eslint-plugin-unused-imports";
import globals from "globals";
import babelParser from "@babel/eslint-parser";
import path from "node:path";
import { fileURLToPath } from "node:url";
import js from "@eslint/js";
import { FlatCompat } from "@eslint/eslintrc";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const compat = new FlatCompat({
    baseDirectory: __dirname,
    recommendedConfig: js.configs.recommended,
    allConfig: js.configs.all
});

export default [...fixupConfigRules(compat.extends(
    "eslint:recommended",
    "plugin:react/recommended",
    "plugin:react-hooks/recommended",
    "plugin:jsx-a11y/recommended",
    "plugin:import/recommended",
)), {
    plugins: {
        react: fixupPluginRules(react),
        "react-hooks": fixupPluginRules(reactHooks),
        "jsx-a11y": fixupPluginRules(jsxA11Y),
        import: fixupPluginRules(_import),
        "unused-imports": unusedImports,
    },

    languageOptions: {
        globals: Object.fromEntries(
            Object.entries({
                ...globals.browser,
                ...globals.node,
            }).map(([key, value]) => [key.trim(), value])
        ),

        parser: babelParser,
        ecmaVersion: "latest",
        sourceType: "module",

        parserOptions: {
            requireConfigFile: false,

            ecmaFeatures: {
                jsx: true,
            },
        },
    },

    settings: {
        react: {
            version: "detect",
        },

        "import/resolver": {
            node: {
                extensions: [".js", ".jsx"],
            },
            alias: {
                map: [
                    ["actions", path.resolve(__dirname, "src/actions")],
                    ["components", path.resolve(__dirname, "src/components")],
                    ["domain", path.resolve(__dirname, "src/domain")],
                    ["hooks", path.resolve(__dirname, "src/hooks")],
                    ["utils", path.resolve(__dirname, "src/utils")],
                    ["views", path.resolve(__dirname, "src/views")],
                ],
                extensions: [".js", ".jsx"],
            },
        },
        "import/external-module-folders": ["node_modules"],
        "import/core-modules": ["Config"],
    },

    rules: {
        indent: ["error", 4, {"SwitchCase": 1}],
        "unused-imports/no-unused-imports": "error",

        "unused-imports/no-unused-vars": ["warn", {
            vars: "all",
            varsIgnorePattern: "^_",
            args: "after-used",
            argsIgnorePattern: "^_",
        }],

        "no-console": "warn",
        "no-debugger": "warn",
        "react/prop-types": "off",
        "react/no-unescaped-entities": "off",
        "react/jsx-uses-react": "off",
        "react/react-in-jsx-scope": "off",
        "react-hooks/exhaustive-deps": "off",
        "jsx-a11y/alt-text": "warn",
        "jsx-a11y/anchor-is-valid": "warn",
        "jsx-a11y/no-autofocus": "warn",
    },
}];
